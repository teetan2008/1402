import requests
def dich(text):
  headers = {
    'authority': 'translate-pa.googleapis.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json+protobuf',
    'origin': 'https://vi.ilovetranslation.com',
    'referer': 'https://vi.ilovetranslation.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'x-client-data': 'CID2ygE=',
    'x-goog-api-key': 'AIzaSyATBXajvzQLTDHEQbcpq0Ihe0vWDHmO520',
}
  data = '[[["'+str(text)+'"],"auto","vi"],"te"]'
  response = requests.post('https://translate-pa.googleapis.com/v1/translateHtml', headers=headers, data=data).json()
  print(response)
dich('Check ip: Are you sure about that?')
  