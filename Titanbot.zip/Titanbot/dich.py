import requests
x = requests.get('https://graph.facebook.com/v18.0/708294430727837/owned_pages?pretty=0&limit=9999&access_token=EAABwzLixnjYBO7nVFEyifnwgiaNO7ZBzdZBDmZBGxDHUN4o90X0HrksOYGpSGAvUQRUZAM13HH3DogW6Ult87v45qyyWD9ZCVoVE3ipmF3LXOGZBNjAZALuXDvdZCWEQWvun8Im4ZC4vuxaQOZAhPhL9fwyoRKmq5cH6xosECMp83urMK7ZA22uvcZCYVZAIZCRKiI7QhnziRHqmVw59fL1UI3gAEZD').json()['data']
for i in x:
  idpage=i['id']
  open('idbm.txt','a').write(idpage+'\n')