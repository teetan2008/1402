import requests
import time
def chap_nhan(ck,lsd,idset,hs,rev,hsi,fb_dtsg,r,t,idmoi,id_page):
    headers = {
    'authority': 'www.facebook.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'cookie': ck,
    'dpr': '1.875',
    'origin': 'https://www.facebook.com',
    'referer': 'https://www.facebook.com/profile.php?id=61553982616567',
    'sec-ch-prefers-color-scheme': 'light',
    'sec-ch-ua': '"Chromium";v="105", "Not)A;Brand";v="8"',
    'sec-ch-ua-full-version-list': '"Chromium";v="105.0.5195.32", "Not)A;Brand";v="8.0.0.0"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
    'viewport-width': '980',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'ProfilePlusCometAcceptOrDeclineAdminInviteMutation',
    'x-fb-lsd': lsd,
}
    data = {
    'av': idset,
    '__aaid': '0',
    '__user': idset,
    '__a': '1',
    '__req': 't',
    '__hs': hs,
    'dpr': '2',
    '__ccg': 'GOOD',
    '__rev':rev,
    '__s': 'rudaz9:k0wzd3:wdce68',
    '__hsi': hsi,
    '__dyn': '7AzHK4HwkEng5K8G6EjBAg2owIxu13wFG1szEdE98K361twYwJyE24wJwpUe8hwaG0Z82_CxS320om78bbwto886C11wBz83WwtohwGxu782lwv89kbxS2218wc61awko5m1mzXw8W58jwGzE8FU5e7oqBwJK2W5olwUwgojUlDw-wUwxwjFovUaU3qxWm2CVEbUGdwr84i223908O3216xi4UK2K364UrwFg2fwxyo566k1FwgU4q3G1eKufxa3m7E',
    '__csr': 'gjjlfd2WH7PshF-gYZfEGf99shmgG9sxmF2Til4nnWDWq9bs_jZnXb9WROfhtIyqAGHBF5mJd4AXXG8CKWDCVeq9yECRFDyoCF8kmuWCLK58hwyHzVFp9oggDBgxlypogByoCdhUC-4Eix2q2jGHAAzoHyo8UyeDyo88rwUximmuFVU8E7u15wBCwPwoUlAzQ2XAxyexi4E21xWm4EiwcV0zxK1_BwECxu3mUeU4C0yE3ywc20bHwa605Ao01nOECgw3IU1g80C2u5u0aVw9G0imU0WS08tA8E39w0FHw3kU3Ww59w1Hm02ly05CU0aA84Pwj8YE0qzw',
    '__comet_req': '15',
    'fb_dtsg': fb_dtsg,
    'jazoest': '25490',
    'lsd': lsd,
    '__spin_r': r,
    '__spin_b': 'trunk',
    '__spin_t': t,
    'fb_api_caller_class': 'RelayModern',
    'fb_api_req_friendly_name': 'ProfilePlusCometAcceptOrDeclineAdminInviteMutation',
    'variables': '{"input":{"client_mutation_id":"1","actor_id":"'+idset+'","is_accept":true,"profile_admin_invite_id":"'+str(idmoi)+'","user_id":"'+id_page+'"},"scale":2}',
    'server_timestamps': 'true',
    'doc_id': '7642695895794293',
}
    response = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data)
    try:
        return response.json()['data']['accept_or_decline_profile_plus_admin_invite']['comet_profile_banner']['notice']['title']['text']
    except:
      print('Error2')
    
def set_admin(ck_pr5, lsd, id_page, hs, hsi, rev, r, t, fb_dtsg , idset):
    headers = {
    'authority': 'www.facebook.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'cookie': ck_pr5,
    'dpr': '2.06146',
    'origin': 'https://www.facebook.com',
    'referer': 'https://www.facebook.com/settings/?tab=profile_access',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.1"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'viewport-width': '891',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'ProfilePlusCoreAppAdminInviteMutation',
    'x-fb-lsd': lsd,
}
    data = {
    'av': id_page,
    '__aaid': '0',
    '__user': id_page,
    '__a': '1',
    '__req': 'x',
    '__hs': hs,
    'dpr': '2',
    '__ccg': 'EXCELLENT',
    '__rev': rev,
    '__s': 'rorq5t:n2ygyj:zpwqm9',
    '__hsi': hsi,
    '__dyn': '7AzHxqU5a5Q1ryUbFp40C8b8nwgUao5-ewSwMwNw9G2S0im3y4o1DU2_CxS320om782Cwwwqo462mcwfG1Rx62G5Usw9m1YwBgK7o884y1uwoE2swlo5qfK0zEkxe2GewGwsoqBwJK2W5olwuEjUlwhEe872m7-2K0-pobpEbUGdwb61jg2cwMwrUK2K364UrwFg2fwxyo6O1FwgUjwOwWwjHDwywRxW',
    '__csr': 'gml5jMBtHdTLJinsxaSGP5rQqEV939WLxvURp7DhFGQhfyohmGyExpuqVaJauJrHBy99oynG8UG8x2i-E9F9bCyazUbU8UaEK3qu5Kcyo-2t6y9omAGmiEW9wBUe8gxG6E-dyU8oK26imdxe2aazUhwq84O6Ueo2mG0CUW1bwIx-cw9G2u0zU2EyovwLzUcHw1Rmu02S_Gaw04GYw0x1w0QZo08wU0sfxaWwygaUOm05xE0iEGFo0tzw3UU0F-0ma2LgVw1OW0aww42wvE-',
    '__comet_req': '1',
    'fb_dtsg': fb_dtsg,
    'jazoest': '25733',
    'lsd': lsd,
    '__spin_r': r,
    '__spin_b': 'trunk',
    '__spin_t': t,
    'fb_api_caller_class': 'RelayModern',
    'fb_api_req_friendly_name': 'ProfilePlusCoreAppAdminInviteMutation',
    'variables': '{"input":{"additional_profile_id":"'+id_page+'","admin_id":"'+idset+'","admin_visibility":"Unspecified","grant_full_control":false,"actor_id":"'+id_page+'","client_mutation_id":"2"}}',
    'server_timestamps': 'true',
    'doc_id': '5707097792725637',
}
    response = requests.post('https://www.facebook.com/api/graphql/',headers=headers, data=data)
    print(response.text)
    try:
        return response.json()['data']['profile_plus_core_admin_invite']['profile_with_biz_tools']['outgoing_core_app_admin_invites'][0]['profile_admin_invite_id']
    except:
      print('Error')
def nhap_mk(ck_pr5, lsd, id_page, hs, hsi, rev, r, t, fb_dtsg):
    headers = {
    'authority': 'www.facebook.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'cookie': ck_pr5,
    'dpr': '2.06146',
    'origin': 'https://www.facebook.com',
    'referer': 'https://www.facebook.com/settings/?tab=profile_access',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.1"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'viewport-width': '891',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'ProfilePlusMarkReauthedMutation',
    'x-fb-lsd': lsd,
}
    data = {
    'av': id_page,
    '__aaid': '0',
    '__user': id_page,
    '__a': '1',
    '__req': 'w',
    '__hs': hs,
    'dpr': '2',
    '__ccg': 'EXCELLENT',
    '__rev': rev,
    '__s': 'rorq5t:n2ygyj:zpwqm9',
    '__hsi': hsi,
    '__dyn': '7AzHxqU5a5Q1ryUbFp40C8b8nwgUao5-ewSwMwNw9G2S0im3y4o1DU2_CxS320om782Cwwwqo462mcwfG1Rx62G5Usw9m1YwBgK7o884y1uwoE2swlo5qfK0zEkxe2GewGwsoqBwJK2W5olwuEjUlwhEe872m7-2K0-pobpEbUGdwb61jg2cwMwrUK2K364UrwFg2fwxyo6O1FwgUjwOwWwjHDwywRxW',
    '__csr': 'gml5jMBtHdTLJinsxaSGP5rQqEV939WLxvURp7DhFGQhfyohmGyExpuqVaJauJrHBy99oynG8UG8x2i-E9F9bCyazUbU8UaEK3qu5Kcyo-2t6y9omAGmiEW9wBUe8gxG6E-dyU8oK26imdxe2aazUhwq84O6Ueo2mG0CUW1bwIx-cw9G2u0zU2EyovwLzUcHw1Rmu02S_Gaw04GYw0x1w0QZo08wU0sfxaWwygaUOm05xE0iEGFo0tzw3UU0F-0ma2LgVw1OW0aww42wvE-',
    '__comet_req': '1',
    'fb_dtsg': fb_dtsg,
    'jazoest': '25733',
    'lsd': lsd,
    '__spin_r': r,
    '__spin_b': 'trunk',
    '__spin_t': t,
    'fb_api_caller_class': 'RelayModern',
    'fb_api_req_friendly_name': 'ProfilePlusMarkReauthedMutation',
    'variables': '{"input":{"password":{"sensitive_string_value":"#PWD_BROWSER:5:1715426105:AXxQAP3f4UGe8RFi3a6Yz1aiJx24F3GMeqz0oQlHzLWrctpkBw5E3AfgwCK2xRQvyKPkryYD4NrGKDUppaNy9rk4rkD1S8ANqkpBUiwiOJjR9FHV6ViJwn9oQr/wqzNmBIQOsiCJSUaDVqiDqcE="},"actor_id":"'+id_page+'","client_mutation_id":"1"}}',
    'server_timestamps': 'true',
    'doc_id': '5048033918567225',
}
    response = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).text
    print(response)

def fb(cookie):
    headers = {
    'authority': 'www.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    'cookie': cookie,
    'dpr': '1.875',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.1"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'viewport-width': '980',
}
    params = {
    'tab': 'profile_access',
}
   
    
    try:
        access = requests.get('https://www.facebook.com/settings/', params=params, headers=headers).text
        hs = access.split('"haste_session":"')[1].split('"')[0]
        rev = access.split('"server_revision":')[1].split('"')[0]
        hsi = access.split('"hsi":"')[1].split('"')[0]
        fb_dtsg = access.split('["DTSGInitialData",[],{"token":"')[1].split('"')[0]
        lsd = access.split('"LSD",[],{"token":"')[1].split('"')[0]
        r = access.split('"__spin_r":')[1].split(',')[0]
        t = access.split('"__spin_t":')[1].split(',')[0]
        return lsd,hs, hsi, rev, r, t, fb_dtsg
    except Exception as e:
        print('Error:', e)
        print('Log Cookie Fall!')

cookie = input('Nhap Cookie Chua Page: ')
ck=input('Nhap Cookie Nick Nhan Page: ')
idset=input('ID Nguoi Can Set: ')
with open('id.txt','r') as file:
  a=file.read().splitlines()
  m = 0
  for i in a:
    m += 1
    id_page = requests.get(f'https://facebook.com/{i.strip()}').url.split('/')[5]
    ck_pr5=cookie + f'i_user={id_page}'
    lsd,hs, hsi, rev, r, t, fb_dtsg=fb(cookie)
    nhap_mk(ck_pr5, lsd, id_page, hs, hsi, rev, r, t, fb_dtsg)
    idmoi=set_admin(ck_pr5, lsd, id_page, hs, hsi, rev, r, t, fb_dtsg , idset)
    lsd,hs, hsi, rev, r, t, fb_dtsg=fb(ck)
    print(chap_nhan(ck,lsd,idset,hs,rev,hsi,fb_dtsg,r,t,idmoi,id_page))
    print(id_page)
    print(m)
    time.sleep(10)