import requests
def getid(idpage,token,fileluu):
  x = requests.get(f"https://graph.facebook.com/v18.0/{idpage}/locations?limit=9999&access_token={token}").json()
  try:
    idp=[i['id'] for i in x['data']]
    with open(fileluu,"a") as file:
      for a in idp:
        file.write(a+"\n")
  except:
    print(idpage)
token=input("Token:")
fileluu=input("File Luu Id:")
with open("id.txt","r") as fileid:
  x = fileid.readlines()
  for i in x:
    idpage=i.strip()
    getid(idpage,token,fileluu)
    