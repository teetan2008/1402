def remove_first_lines(file_path, lines_to_remove=200):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()

        with open(file_path, 'w') as file:
            file.writelines(lines[lines_to_remove:])

        return True
    except Exception as e:
        return False

# Sử dụng hàm để xóa 200 dòng đầu tiên của file
