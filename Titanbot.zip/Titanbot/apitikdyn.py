import requests
def gettikdyn(url):
  x = requests.get('https://snapdouyin.app/vi/').cookies.get_dict()
  cookies = {
    'PHPSESSID': x['PHPSESSID'],
    'wp-wpml_current_language': 'vi',
}
  headers = {
    'authority': 'snapdouyin.app',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    # 'cookie': 'PHPSESSID=89veo87srhgbse2j058fb7cogf; wp-wpml_current_language=vi',
    'referer': 'https://snapdouyin.app/vi/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
  response = requests.get('https://snapdouyin.app/vi/', cookies=cookies,headers=headers).text
  token=response.split('name="token" value="')[1].split('"')[0]
  print(token)
  cookies = {
    'PHPSESSID': x['PHPSESSID'],
    'wp-wpml_current_language': 'vi',
}
  headers = {
    'authority': 'snapdouyin.app',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'PHPSESSID=89veo87srhgbse2j058fb7cogf; wp-wpml_current_language=vi',
    'origin': 'https://snapdouyin.app',
    'referer': 'https://snapdouyin.app/vi/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
  data = {
    'url': url,
    'token': token,
}
  response = requests.post('https://snapdouyin.app/wp-json/aio-dl/video-data/', cookies=cookies,headers=headers, data=data).json()
  print(response)