import requests
import json
import os
f = open("token.txt", "w")
token=input('Token:')
file_token = open("id.txt").read().split("\n")
for id in file_token:
  try:
    get = requests.get(f"https://b-graph.facebook.com/{id}?fields=access_token&access_token="+ token).json()
    try:
      token_page = get['access_token']
      print(token_page)
      f.write(token_page+'\n')
    except:
        exit()
  except:
    print('loi')
    
