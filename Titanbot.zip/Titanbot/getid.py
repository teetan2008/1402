import requests
def getuid(link):
  headers = {
    'authority': 'fbuid.mktsoftware.net',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json',
    'origin': 'https://mktsoftware.net',
    'referer': 'https://mktsoftware.net/find-fb-uid.html',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  params = {
    'url': link,
}
  try:
    response = requests.get('https://fbuid.mktsoftware.net/api/v1/fbprofile', params=params, headers=headers).json()
    if response['uid'] == '':
      return None 
    uid=response['uid']
    return uid 
  except:
    return None