import requests
import datetime
from time import sleep
import threading

def run(id_post, token):
    try:
        headers = {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'content-length': '0',
            'cookie': "datr=9qYvZRza8BvY9PwFrGywjxyh;vpd=v1%3B752x384x1.875;c_user=100092493308622;m_page_voice=100092493308622;locale=en_GB;fbl_cs=AhApsGO1%2F168F8kCN3etSgBdGFEvaFdFZ2x4dUhlRmdnSlhxUDYwL0tRRQ;fbl_ci=1276103043034255;sb=7QM-ZSvv0Vt_PVeUMFQiGXBE;wd=1024x1088;dpr=1.875;xs=42%3AeoozcF5poi3s7w%3A2%3A1698361876%3A-1%3A5589%3A%3AAcVikEPlGkIscLy6fOkGkbxH2Rt3s_YSryMtGNwdDaM;fr=1ec4QHIW5XqLpWtnd.AWWUOWc7VC6WKm4zIxEfTzbsCPs.BlQi15.GB.AAA.0.0.BlQi15.AWWT4QvTrTA;fbl_st=101421907%3BT%3A28313930;wl_cbv=v2%3Bclient_version%3A2346%3Btimestamp%3A1698835833;",
            'host': 'graph.facebook.com'
        }
        dt_now = datetime.datetime.now()
        response = requests.post(f'https://graph.facebook.com/me/feed?method=POST&link=https://m.facebook.com/{id_post}&published=0&access_token={token}', headers=headers).json()
        sleep(1)
        if 'id' in response:
            print(f"{dt_now.strftime('%H:%M:%S')} | {response['id']}")
            return True
        else:
            print(f"{dt_now.strftime('%H:%M:%S')}: SHARE POST FAILED!")
            return False
    except Exception as e:
        print(f"An error occurred: {e}")
        return False

def shares(id_post, lan):
    list_token = []
    with open('token.txt', 'r') as file:
        list_token = file.read().splitlines()
    sotk = len(list_token)
    print(f"Total tokens: {sotk}")
    dem = 0

    def thread_function(token):
        nonlocal dem
        if run(id_post, token):
            dem += 1

    threads = []

    while True:
        for token in list_token:
            thread = threading.Thread(target=thread_function, args=(token,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        print(f"Successful shares: {dem}")
        if dem >= int(lan):
            return True
            break
