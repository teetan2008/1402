import requests
import time , random
def run(idfb,token):
    cookie=open('cookie.txt','r').read().strip()
    useragent=['Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.0; x64; en-US Trident/6.0)','Mozilla/5.0 (Windows NT 10.5; x64) AppleWebKit/600.44 (KHTML, like Gecko) Chrome/49.0.2898.222 Safari/601','Mozilla/5.0 (Linux; Android 5.1.1; MOTO X PURE XT1575 Build/LXB22) AppleWebKit/600.42 (KHTML, like Gecko)  Chrome/54.0.3593.354 Mobile Safari/602.5','Mozilla/5.0 (iPhone; CPU iPhone OS 8_7_7; like Mac OS X) AppleWebKit/533.48 (KHTML, like Gecko)  Chrome/49.0.1488.291 Mobile Safari/601.7','Mozilla/5.0 (Linux; U; Android 5.1; MOTOROLA MOTO XT1580 Build/LMY47Z) AppleWebKit/603.44 (KHTML, like Gecko)  Chrome/51.0.1620.369 Mobile Safari/601.9','Mozilla/5.0 (Windows; U; Windows NT 10.5; Win64; x64; en-US) Gecko/20100101 Firefox/58.7','Mozilla/5.0 (Linux; U; Linux i681 ) AppleWebKit/534.40 (KHTML, like Gecko) Chrome/51.0.2244.260 Safari/534','Mozilla/5.0 (Macintosh; U; Intel Mac OS X 7_9_8) AppleWebKit/536.2 (KHTML, like Gecko) Chrome/54.0.3486.369 Safari/601','Mozilla/5.0 (Android; Android 5.0.1; HTC 80:number1-2s Build/JSS15J) AppleWebKit/601.19 (KHTML, like Gecko)  Chrome/53.0.2488.138 Mobile Safari/533.4','Mozilla/5.0 (Android; Android 5.0.1; HTC 80:number1-2s Build/JSS15J) AppleWebKit/601.19 (KHTML, like Gecko)  Chrome/53.0.2488.138 Mobile Safari/533.4','Mozilla/5.0 (Windows NT 10.1; x64) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/51.0.1551.381 Safari/535.1 Edge/11.82994']
    headers={
      "cookie":cookie,
      "upgrade-insecure-requests":"1",
      "user-agent":random.choice(useragent),
	    "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    	"dnt":"1",
    	"x-requested-with":"mark.via.gp",
    	"sec-fetch-site":"none",
    	"sec-fetch-mode":"navigate",
    	"sec-fetch-user":"?1",
    	"sec-fetch-dest":"document",
    	"accept-encoding":"gzip, deflate",
    	"accept-language":"vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
}
    x = requests.get(f"https://graph.facebook.com/{idfb}/likes?method=POST&access_token={token}",headers=headers).text
    print(x)
    time.sleep(10)
def like(idfb,a):
  with open('token.txt','r') as file:
    x=file.readlines()
    for i in x[:a]:
      token=i.strip()
      run(idfb,token)
like('408791364872116',100)