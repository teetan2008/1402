import requests
import time
def run(idpage,bucket_id,idstr,url,jazoest,i,fb_dtsg):
  cookie=open('cookie.txt','r').read().strip()
  ck_pr5 = f'{cookie}i_user={idpage}'
  headers = {
        'authority': 'www.facebook.com',
        'accept': '*/*',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'origin': 'https://www.facebook.com',
        'referer': url,
        'sec-ch-prefers-color-scheme': 'light',
        'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        'viewport-width': '1186',
        'x-fb-friendly-name': 'storiesUpdateSeenStateMutation',
        'x-fb-lsd': 'YCCQAywyZyd74odVp6QBrw',
        'cookie': ck_pr5,
    }
  data = {
        'av': idpage,
        '__user': idpage,
        'fb_dtsg': fb_dtsg,
        'jazoest': jazoest,
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'storiesUpdateSeenStateMutation',
        'variables': '{"input":{"bucket_id":"'+bucket_id+'","story_id":"'+str(idstr)+'","actor_id":"'+idpage+'","client_mutation_id":"1"},"scale":1}',
        'server_timestamps': 'true',
        'doc_id': '5127393270671537',
    }
  while True:
    try:
      runview = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).json()
      print(runview,i)
      time.sleep(1)
      break 
    except:
      continue
def start(idstr,a):
  idstr=str(idstr)
  cookies = {
    'datr' : '3OBTZgdTeRU3CIAcHsQT4t58',
    'c_user': '100093063091825',
    'fr': '1TjtNpvXV1vg2iCLK.AWUAbMkxpoml22nvvKDgX72kKiw.BmU-Jb..AAA.0.0.BmU-KL.AWWo5RAqQ_E;',
    'xs': '6%3Ah0s2ido-n_9FGA%3A2%3A1716773083%3A-1%3A6274%3A%3AAcUKQYR9hpY0QLmJJ_0xnh8i2ITLmutwldy4he8iPQ',
}
  headers = {
    'authority': 'www.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'viewport-width': '980',
}
  try:
    response = requests.get(f'https://www.facebook.com/{idstr}',headers=headers,cookies=cookies)
    url=response.url
    bucket_id=url.split('/')[4]
    idstr=url.split('/')[5]
    fb_dtsg = response.text.split('["DTSGInitialData",[],{"token":"')[1].split('"')[0]
    jazoest=response.text.split('param_name":"')[1].split('"')[0]
    with open('idngoc.txt','r') as file:
      x = file.readlines()
      i = 0
      for m in x[:a]:
        i += 1
        idpr5=m.strip()
        run(idpr5,bucket_id,idstr,url,jazoest,i,fb_dtsg)
    return True
  except:
    return False