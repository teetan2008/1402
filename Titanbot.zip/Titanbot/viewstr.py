import requests
import time
def view(cookie, fb_dtsg, jazoest, idstr, link, id_page,i):
        ck_pr5 = f'{cookie}i_user={id_page}'
        headers = {
        'authority': 'www.facebook.com',
        'accept': '*/*',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'origin': 'https://www.facebook.com',
        'referer': link,
        'sec-ch-prefers-color-scheme': 'light',
        'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        'viewport-width': '1186',
        'x-fb-friendly-name': 'storiesUpdateSeenStateMutation',
        'x-fb-lsd': 'YCCQAywyZyd74odVp6QBrw',
        'cookie': ck_pr5,
    }
        data = {
        'av': id_page,
        '__user': id_page,
        'fb_dtsg': fb_dtsg,
        'jazoest': jazoest,
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'storiesUpdateSeenStateMutation',
        'variables': '{"input":{"bucket_id":"259253279258515","story_id":"'+str(idstr)+'","actor_id":"'+id_page+'","client_mutation_id":"1"},"scale":1}',
        'server_timestamps': 'true',
        'doc_id': '5127393270671537',
    }
        runview = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).json()
        print(runview , i)
        time.sleep(2)
def process_id_page(cookie, fb_dtsg, jazoest, idstr, link, id_page,i):
        try:
            view(cookie, fb_dtsg, jazoest, idstr, link, id_page,i)
        except Exception as e:
            print(f"Error processing id_page {id_page}: {e}")

def process_id_pages(cookie, fb_dtsg, jazoest, idstr, link, id_pages,a):
        i =0
        for id_page in id_pages[:a]:
            i+=1
            id_page = id_page.strip()
            process_id_page(cookie, fb_dtsg, jazoest, idstr, link, id_page,i)

def fb(idstr,link,a):
        cookie='datr=Ag97ZQkf2HI76IguHusu-GkE; sb=DQ97ZXbUjyNXSnJZhVvdQhRw; c_user=100093063091825; fbl_st=101431517%3BT%3A28386137; wl_cbv=v2%3Bclient_version%3A2378%3Btimestamp%3A1703168219; fbl_cs=AhAOeGREXOiGDQtioJRZm7CFGD12QkVId3VOWTRtRmVGU2ttVmNQcHdCdg; fbl_ci=604105845253212; vpd=v1%3B947x891x2.061462879180908; m_page_voice=100093063091825; dpr=2.061462879180908; wd=891x1745; xs=13%3A2o1uG4PSJma42A%3A2%3A1703161930%3A-1%3A6274%3A%3AAcUhZ_M3EFxL3zclN8ihKwYORxyJp82Mjv7q9gQBhHo; fr=1idOuBJjcz3OZNUio.AWUJ8WkqzXYcrxhYzc0-HitVfe0.BlkSx8.7I.AAA.0.0.BlkUDt.AWWSTW5OB2k; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTIwLjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F120.0.0.0%20Mobile%20Safari%2F537.36; '
        headers = {
        'authority': 'mbasic.facebook.com',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Google Chrome";v="93", " Not;A Brand";v="99", "Chromium";v="93"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://mbasic.facebook.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://mbasic.facebook.com/',
        'accept-language': 'en-US,en;q=0.9',
        'cookie': cookie
    }
        try:
            find_data = requests.get("https://mbasic.facebook.com/", headers=headers).text
            fb_dtsg = find_data.split('<input type="hidden" name="fb_dtsg" value="')[1].split('"')[0]
            jazoest = find_data.split('<input type="hidden" name="jazoest" value="')[1].split('"')[0]
            with open('idngoc.txt', "r") as fileid:
                id_pages = fileid.readlines()
            process_id_pages(cookie, fb_dtsg, jazoest, idstr, link, id_pages,a)
        except Exception as e:
            print(f"Error: {e}")
