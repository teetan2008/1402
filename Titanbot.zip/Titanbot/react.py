import requests
import random
import uuid
from time import sleep
def run(ck_pr5,idpage,lsd,hs, hsi, rev, r, t, fb_dtsg,feedback_id,typecx):
  headers = {
    'authority': 'www.facebook.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'cookie': ck_pr5,
    'origin': 'https://www.facebook.com',
    'referer': 'https://www.facebook.com/',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'CometUFIFeedbackReactMutation',
    'x-fb-lsd': lsd,
}
  data = {
    'av': idpage,
    '__aaid': '0',
    '__user': idpage,
    '__a': '1',
    '__req': 'r',
    '__hs': hs,
    'dpr': '3',
    '__ccg': 'EXCELLENT',
    '__rev': rev,
    '__s': 'f1qp6d:0btk79:8qdnty',
    '__hsi': hsi,
    '__dyn': '7AzHxqU5a5Q1ryaxG4Vp40C8b8nwgUao4u5QdwSwMwNw9G2Saw8i2S1DwUx60p-0LVEtwMw65xO321Rwwwqo462mcwfG12wOx62G5Usw9m1YwBgK7o884y0Mo4G1hx-3m1mzXw8W58jwGzE9WwkUtxGm2SUbElxm3y11xfxmu3W3y1MBx_wHwfCm2Sq2-azo2NwwwOg2cwMwhEkxebwHwNxe6Uak0zU8oC1hxB0qo4e16wWwjHDwywRxW1ow',
    '__csr': 'g8AAp6Nn2FBiAEAgCx6CjPlYAhjlOOduluGRl4iGihLj8iKpHZbmhkyOJGJpptBGt9968aADQeKVrhAi8gFeiVpqh48y8GaoCQFQfAx2p5jBSq4JacCKquVbz-bmEtBxOqq2aqbCxe7FGDxJKueByHBxe8Byu8xa5Wxum6EC2m6o9awk8S10wMCwIwuo9U8Gw921JyU461CwnU2swfu4U4C0mS0gW0cow7Jw2bE0g9w05dVg1IE1o40cwg2Mw19C04VE1Fo1NU04nS01Fow2voS0he1Zw',
    '__comet_req': '15',
    'fb_dtsg': fb_dtsg,
    'jazoest': '25327',
    'lsd': lsd,
    '__spin_r': r,
    '__spin_b': 'trunk',
    '__spin_t': t,
    'fb_api_caller_class': 'RelayModern',
    'fb_api_req_friendly_name': 'CometUFIFeedbackReactMutation',
    'variables': '{"input":{"attribution_id_v2":"CometHomeRoot.react,comet.home,via_cold_start,1715553818217,124580,4748854339,,","feedback_id":"'+feedback_id+'","feedback_reaction_id":"'+typecx+'","feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":["AZUJ0xR-xWxoFntT74P1OxPsizGvvApr7NodCrE8NbRBMGQs53OfBwKyz-KhF7zFyidbB3cPb4LCdoFrOl3PQ3lmkEXkhpzhW7leUfgzCUMgmfO6MVRgHmIZPlXeAeo5pj_wGP-gm_1RK_QOzzV5YYx7Lw2-qrga9EyOYPOafwgAfmXSipLDrKYzjRYjkNvw4_owSxTcmVNU1nTBQG48dGLEQ75CRK33RiJlK5L-5er6XwK9mGpA9xURVY23mrgHEvBQnpfJoW5GiTKqhYCFRcHyKchB3D768LBeYPeUKB4Uq7EJGuw0ysbJy1wSouOI6TnI27cAgVKAH8nImu4G_nn61hzaOPwG3r0o-fHbb2-GErZh3JGwzfWJqO9avP8cwOPvOLA-1H08RRBM94b_-d8eKFkwrYQlZagRskG5CADR3cXXoaEvzVRID0RzvSXbJG_DDJy5FxPyOdHu6VTxOk2uB7aRuUpe9QnsB7BrH5JErvpoMdfxG-80vYuplT4iQuk2cju09oR5ss9W3XLK8d9VYhwo61GP8vLrWC_Wle2scSETThFrOAUahHB_TwVi3vbnxzamzbc9FLRILgSYOnSqs7120eqqkkumY69Jtl0WVRNVLwF9StiTpACwgJOp_GNY6lWT2ASdGez8zJWOSjJAKMo3wisuAdEuipv5ZNqpeyC4NXPfA4cE3_lT5IngOaHtN89AoxVqDu1I9Gc7hCpSTIbe6MjiE0rasRPs9sOjV9mtvYJ5PJ7Cf9JO3aKEYgNnLjwD8zD3tSRWlQ6AxYME1lNJDHopmEDOfddIq92IhQ2ofIE3oyYvvYrF5nkP33FfnSuweMq1JAsemIvMlY34CEqKCtqVrsKqmeDiAz9Zo6jL0A6_Txoe-SolWE4xuKZmr7LDmM2igPF6fqiwZsr10Y8KjpPcfChL-i1aYY53RA3tDVX153iVUymKv7F3bROEb2iXjBEe41jcPntSmn949eO2jxbjLSIxmxN3t1Z0XUeOjDa65SP72V2sJ2oAdl1iv-eYXQTyumM7LogTqP02YTsZavV7Dc-uqu9CbFn-UsPUf6E-XUPvllS3PsC7PCvjEP1qGk1f6LUyYK-OgvoI9Gt7b60szbetd2Wv6MqYxE7WO6igLcnEOPUHXYeA3DhOK0HXOO0m89ua6E1Mc60tfIPUR9zUWLnf8hkUZbsKfWqB7YJqXuEjySW7yYE1Olu6KG_pplSZ_8e3195tKCG79L1fWkGv-HNKMbVjQgnvkqkeQTUId59XG2_x2SpVbemi-99uK6RN2HOvH8BHRbbswVN02Jjj8N7cLqEjoj_5251ZPFKTs3UcuBWt-xz3WLsdajv4mKkuNdFnVtjy0gndGPwsUN2Wdb5UYAUZoADpz-r5DPZAMZozrz7bHlqnX78z5s1A5C7JaMoKTrIpjR71EjWkISNkFmOsGQCWy2etagei8sRdIYZe5jYZuwpxDuVapIsqDgrWN2ffr-DSQE-JeV4HzyEvOglna9n_-_gtu16eV82MKo8pDTbD0qI_fyOGgL9wyjpvAP7DoManAGJ_"],"session_id":"'+str(uuid.uuid4())+'","actor_id":"'+idpage+'","client_mutation_id":"1"},"useDefaultActor":false,"scale":3}',
    'server_timestamps': 'true',
    'doc_id': '6880473321999695',
}

  response = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).text
  return response
def fb(ck_pr5,idpage,feedback_id,typecx):
  headers = {
    'authority': 'www.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    'cookie': ck_pr5,
    'dpr': '1.875',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'viewport-width': '980',
}
  try:
        access = requests.get('https://www.facebook.com/', headers=headers).text
        hs = access.split('"haste_session":"')[1].split('"')[0]
        rev = access.split('"server_revision":')[1].split('"')[0]
        hsi = access.split('"hsi":"')[1].split('"')[0]
        fb_dtsg = access.split('["DTSGInitialData",[],{"token":"')[1].split('"')[0]
        lsd = access.split('"LSD",[],{"token":"')[1].split('"')[0]
        r = access.split('"__spin_r":')[1].split(',')[0]
        t = access.split('"__spin_t":')[1].split(',')[0]
        cx=run(ck_pr5,idpage,lsd,hs, hsi, rev, r, t, fb_dtsg,feedback_id,typecx)
        return cx
  except:
    return False
def type_cx(type_1) :
	if type_1 == 1 :
		type_2 = '1678524932434102'
		#Love
	elif type_1 == 0:
	  type_2 = '1635855486666999'
	  #Like
	elif type_1 == 2 :
		type_2 = '613557422527858'
		#Care
	elif type_1 == 3 :
		type_2 = '478547315650144'
		#Wow
	elif type_1 == 4 :
		type_2 = '115940658764963'
		#Haha
	elif type_1 == 5 :
		type_2 = '908563459236466'
		#Sad
	elif type_1 == 6 :
		type_2 = '444813342392137'
		#Angry
	return type_2
def reacts(id_post,lan,type_1):
  i=0
  with open('ck.txt','r') as files:
    ck = files.read().splitlines()
  with open('idall.txt','r') as file:
    a = file.read().splitlines()
    m = 0
    n = 0
    x = len(ck)
    try:
      headers = {
    'authority': 'www.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    'cookie': open('cookie.txt','r').read().strip(),
    'dpr': '1.875',
    'sec-ch-prefers-color-scheme': 'dark',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Linux"',
    'sec-ch-ua-platform-version': '""',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'viewport-width': '980',
}
      url = requests.get('https://www.facebook.com/'+id_post, headers=headers).url
      home = requests.get(url, headers=headers).text
      feedback_id = home.split('parent_feedback":{"id":"')[1].split('"')[0]
      for i in a[:lan]:
        idpage = requests.get(f'https://facebook.com/{i.strip()}').url.split('/')[5]
        while True:
          typecx=type_cx(type_1)
          cookies=ck[m]
          idacc=cookies.split('c_user=')[1].split(';')[0]
          ck_pr5 = f'{cookies};i_user={idpage}'
          start=fb(ck_pr5,idpage,feedback_id,typecx)
          print(start)
          print(idpage,'|',idacc,n)
          if feedback_id in str(start):
            m += 1
            n += 1
            if m == x:
              m =0
            sleep(15)
            break
          else:
            m += 1
            if m == x:
              m = 0
            print(cookies,'| \033[1;31mDIE\033[1;37m')
            continue
      return True
    except :
      return False