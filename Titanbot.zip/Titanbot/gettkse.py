import requests
tk=[]
with open('tk.txt','r') as file:
  a = file.read().splitlines()
  for i in a:
    tk.append(i.strip())
with open('idall.txt','r') as file:
  a = file.read().splitlines()
  m = 0
  n = len(tk)
  for i in a:
    while True:
      token=tk[m]
      m += 1
      if m == n:
        m = 0
      try:
        x = requests.get(f'https://graph.facebook.com/v18.0/{i.strip()}?fields=access_token&access_token={token}').json()
        access_token=x['access_token']
        open('token.txt','a').write(access_token+'\n')
        break
      except:
        print(x)
        print(i.strip(),'|',token)
    