import requests
from time import sleep

def set(cookie, idpage, idpr5, idacc, hsi, hs, rev, fb_dtsg, lsd, r, t):
    headers = {
        'authority': 'business.facebook.com',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'cookie': cookie,
        'origin': 'https://business.facebook.com',
        'referer': f'https://business.facebook.com/latest/settings/pages?business_id=708294430727837&selected_asset_id={idpage}&selected_asset_type=page',
        'sec-ch-prefers-color-scheme': 'light',
        'sec-ch-ua': '"Chromium";v="105", "Not)A;Brand";v="8"',
        'sec-ch-ua-full-version-list': '"Chromium";v="105.0.5195.32", "Not)A;Brand";v="8.0.0.0"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
        'x-asbd-id': '129477',
        'x-fb-friendly-name': 'BusinessToolsAssignUserToAssetModalMutation',
        'x-fb-lsd': lsd,
    }
    data = {
        'av': idacc,
        '__usid': '6-Tsdrjpfnmnuzt:Psdrjp84jgfsi:0-Asdrjpf1oot9nl-RV=6:F=',
        '__aaid': '0',
        '__bid': '708294430727837',
        '__user': idacc,
        '__a': '1',
        '__req': '18',
        '__hs': hs,
        'dpr': '1',
        '__ccg': 'EXCELLENT',
        '__rev': rev,
        '__s': 'n56lbt:y8xaxj:vwdc1m',
        '__hsi': hsi,
        '__dyn': '7xeUmxa2C6oCdwn8K2Wmhe5UkBw8W5VEdpE6C4UKewSAxam4Eco5S3O2S2q1VwqoqyojzoO4o2vwOwNCwQwCxq0yFE4WqbwQzobVqxN0Cm3S1dwu8swEK2y1gwBwXwEwgo9oO1WwamcwgECu7E422a3Gi6rxi1aDwFwBgao884y3m2y1bxq1yxJxK48G2q4p8aHwzzXwKwjovCxeq4ohzEaE8o4-224U-9K2W2K4E5yeDy-1ezo8EfEO32fxiF-3a2WE4e8yE4C4oKqbx6fwLCyKbwzweau0Jo6-3u36iU9E4KeCK2q1pwjouxK2i2y13xy0FU7i7E5y',
        '__csr': 'gac4YIeglHn8OEyaxIBOiayeDivXiisZ-BvtFlZbVvJqddspiXF8Jh3ikYJOS_ti4A9mG8QBiCdRruBuQbEyGhKRF9lRaG-Fmh9qghiykBF4BqG9Ak-aQpeuGV48gQF8NmVSEJGUy-uF23pagk-uryUCKmWDmunWl6yLyoF2_hqG8yVXBgJ2A9-mjzuqfyut28CpeESbBGlqDGhuEyFK8AhXxiXKqcG9AyoG8GqEizpbuVUyGGXJK9CGA9LKiu4K5LinzktCz8CcABKuWLDXwKgKfyoKbxeq9xGu4amuA_zpXjyoOeKeHwpo8oyi5XAVGwLxau329G6oC364E8EiBwrEGU98kwi98hCgcWzEG68gwiESu7qwGG3e1hxu043U4meMlgkah123W2J3U15Q0lu1vyMC0oy48GbCDgybwXK480HG4Vi7ADxx4ypFpk9g9U0ioo0Ap3VC1Ww2Xo10EWbCw9C0Doqo9CEW2C5o5-u8w12u09sU8y0mgAE-pzQexNjN7IZ9waO0m503-VB80o6u11w4Twww0Oyw4Y2FhMk9bg7O0i-yEy9fU9A2B5sU0LEjeEigkwpYklhRDxiewa50mvEyx9e4HgS2Al47He0ou1Z87A2W3QODmsk2K0gHf80gi1Ng3T2F1Mne220gW2i0To1F8uyo2Uw1oK0gW4U1wk0SU0iIwfK4EkOwz4yE9A0btho4h6N2y10n-A2ybCxpCwFw1kK0l-2-2yyJ00Q3w1sV1e02aG4EkS0ie8xl0Co7V02Wy03T4u04No7Aw496DxqlU0kWw3wE1G40Oo',
        '__comet_req': '11',
        'fb_dtsg': fb_dtsg,
        'jazoest': '25598',
        'lsd': lsd,
        '__spin_r': r,
        '__spin_b': 'trunk',
        '__spin_t': t,
        '__jssesw': '1',
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'BusinessToolsAssignUserToAssetModalMutation',
        'variables': '{"businessID":"708294430727837","assetID":"'+idpage+'","userIDs":["61560204145924"],"taskIDs":["461340961883703","2565488997052663","556750461849806","275298030109664","696659004201852","270956550540539","794616964377599","290727579301631"]}',
        'server_timestamps': 'true',
        'doc_id': '7024986130939271',
    }
    response = requests.post('https://business.facebook.com/api/graphql/', headers=headers, data=data).json()
    return response

def fb(cookie, idpr5, idpage):
    headers = {
        'authority': 'www.facebook.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
        'cache-control': 'max-age=0',
        'cookie': cookie,
        'dpr': '1.875',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.1"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Linux"',
        'sec-ch-ua-platform-version': '""',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'viewport-width': '980',
    }
    params = {
        'tab': 'profile_access',
    }

    try:
        idacc = cookie.split("c_user=")[1].split(";")[0]
        access = requests.get('https://www.facebook.com/settings/', params=params, headers=headers).text
        hs = access.split('"haste_session":"')[1].split('"')[0]
        rev = access.split('"server_revision":')[1].split('"')[0]
        hsi = access.split('"hsi":"')[1].split('"')[0]
        fb_dtsg = access.split('["DTSGInitialData",[],{"token":"')[1].split('"')[0]
        lsd = access.split('"LSD",[],{"token":"')[1].split('"')[0]
        r = access.split('"__spin_r":')[1].split(',')[0]
        t = access.split('"__spin_t":')[1].split(',')[0]
        setqtv = set(cookie, idpage, idpr5, idacc, hsi, hs, rev, fb_dtsg, lsd, r, t)
        return setqtv,idacc
    except:
        return setqtv

n = 0
with open('ck.txt', 'r') as file:
    ck = file.read().splitlines()

with open('id.txt', 'r') as file:
    a = file.read().splitlines()
    m = 0
    for i in a:
        while True:
            try:
                
                cookie = ck[n]
                n += 1
                if n == len(ck):
                    n = 0
                
                idpage = i.strip()
                idpr5 = requests.get(f'https://facebook.com/{i.strip()}').url.split('/')[5]
                run, idacc = fb(cookie, idpr5, idpage)
                
                if 'SUCCESS' in str(run):
                    m += 1
                    print(idpage, '| Success |', m, '|', idacc)
                    sleep(30)
                    break
                else:
                      # Remove the cookie that caused the failure
                    print(run, idacc)
            except Exception as e:
                  # Ensure not to pop an out of range index
                print(f"Error: {e}",idacc)

        