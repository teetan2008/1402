import requests
def xoavtri(store_code,idpage,idvtri):
  cookies = {
    'dpr': '2.061462879180908',
    'sb': '3-80ZoRdcYGlgOV2iGTSZWCx',
    'datr': '3-80ZpdVcVfopGIZn9TzzGWB',
    'ps_n': '1',
    'ps_l': '1',
    'locale': 'en_GB',
    'wl_cbv': 'v2%3Bclient_version%3A2498%3Btimestamp%3A1715596122',
    'c_user': '100093063091825',
    'xs': '17%3A-V_wASJ_YkuXmQ%3A2%3A1715596321%3A-1%3A6274%3A%3AAcUQvj79Bj8qxw5890bXF7pXu52zGN2C2faekKgl5A',
    'fr': '12KSwGX1D32JotURr.AWVqMnv6EdSOjCtWS70xYgIIjSs.BmQ1fq..AAA.0.0.BmQ1fq.AWVfR87Xu7o',
    'usida': 'eyJ2ZXIiOjEsImlkIjoiQXNkaDZnaTFvNWQ2cHUiLCJ0aW1lIjoxNzE1Njg5NDk2fQ%3D%3D',
    'i_user': '61554122921365',
    'wd': '891x1745',
}
  headers = {
    'authority': 'graph.facebook.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'dpr=2.061462879180908; sb=3-80ZoRdcYGlgOV2iGTSZWCx; datr=3-80ZpdVcVfopGIZn9TzzGWB; ps_n=1; ps_l=1; locale=en_GB; wl_cbv=v2%3Bclient_version%3A2498%3Btimestamp%3A1715596122; c_user=100093063091825; xs=17%3A-V_wASJ_YkuXmQ%3A2%3A1715596321%3A-1%3A6274%3A%3AAcUQvj79Bj8qxw5890bXF7pXu52zGN2C2faekKgl5A; fr=12KSwGX1D32JotURr.AWVqMnv6EdSOjCtWS70xYgIIjSs.BmQ1fq..AAA.0.0.BmQ1fq.AWVfR87Xu7o; usida=eyJ2ZXIiOjEsImlkIjoiQXNkaDZnaTFvNWQ2cHUiLCJ0aW1lIjoxNzE1Njg5NDk2fQ%3D%3D; i_user=61554122921365; wd=891x1745',
    'origin': 'https://business.facebook.com',
    'referer': 'https://business.facebook.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
}
  params = {
    'access_token': 'EAAGNO4a7r2wBOw878sJ1h6ToK9dCJD25psd2Uj5cGydmkBCCneYLfw4lWjDrEcxZBvyYMXk4zUiWA5ZCGQQHP1BXmyfrcnLSVjUZAdSyJvNobA1gAZC15X8ymIaDZCPBcztdN6ioehWlEgZCuwn9YZBKUXiESFZCjZARjwvAImkQZCSCvzfKmqyhulN6ySwwcejwC46EKBoUIwUmfsPZCZAewZB4M',
}
  data = {
    '__activeScenarioIDs': '[]',
    '__activeScenarios': '[]',
    '__interactionsMetadata': '[]',
    '_reqName': 'object:page/locations',
    '_reqSrc': 'LocationManagerUtils',
    'locale': 'en_GB',
    'location_page_ids': '["'+idvtri+'"]',
    'method': 'delete',
    'pretty': '0',
    'store_numbers': '['+store_code+']',
    'suppress_http_code': '1',
    'xref': 'f6d2da94e78759487',
}
  response = requests.post(
    f'https://graph.facebook.com/v18.0/{idpage}/locations',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
).json()
  print(response)
with open('id.txt','r') as file:
  a = file.read().splitlines()
  for i in a:
    x=requests.get(f'https://graph.facebook.com/v18.0/{i.strip()}?fields=store_code,parent_page&access_token=EAABwzLixnjYBO5dD4pw7qeiWRSZALEFFor0SM321ytZCaxJmT5SZCwCsmhDpmWTSjw9EbTqnhjp7knZCe9zLmI8oRSremnfSLqFxf7BJJvqdtZBo8eVJO5rwK6jyjFe0zwYJvap9sqhfVIND0frMbo5WAGZA85T1CHZAAZBYZCVDcvJeX04DLCiB9DzOnZBvAJtBE2JZCkTlEbYd5W6RIhkvQYZD').json()
    try:
      store_code=x['store_code']
      idpage=x['parent_page']['id']
      idvtri=x['id']
      xvtri=xoavtri(store_code,idpage,idvtri)
    except Exception as e:
      print(e)
      print(i.strip())