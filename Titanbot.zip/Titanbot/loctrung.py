file_path = input('File: ')
unique_lines = set()

with open(file_path, 'r') as file:
    for line in file:
            unique_lines.add(line)

with open('id.txt', 'w') as output_file:
    for line in unique_lines:
        output_file.write(line )
