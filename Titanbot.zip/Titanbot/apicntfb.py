import requests
import json
def checkid(uid):
  check=requests.get(f'https://graph.facebook.com/{uid}?fields=id,is_verified,cover,created_time,work,hometown,username,link,name,locale,location,about,website,birthday,gender,relationship_status,significant_other,quotes,first_name,subscribers.limit(0)&access_token=EAAD6V7os0gcBOyoP7KrXhMEPz8iBca1vM8YVyoApY2sr8wJDVwogoVq7A9H1xyaxvZAwKpkKcOsYznCbOxZBGhEbbasoHnssqZALIG7fyi876N3ef1VeA5hSLOpzI1M9owNnLZAEzpidRdUZCv0h2p21cheIu7klFPV9fZCED5nu9ITR1tOBFKJ1woxbhXhy7TxgZDZD').json()
  avarta=requests.get(f'https://graph.facebook.com/{uid}/picture?redirect=0&type=normal&height=350&width=350&access_token=EAAD6V7os0gcBOyoP7KrXhMEPz8iBca1vM8YVyoApY2sr8wJDVwogoVq7A9H1xyaxvZAwKpkKcOsYznCbOxZBGhEbbasoHnssqZALIG7fyi876N3ef1VeA5hSLOpzI1M9owNnLZAEzpidRdUZCv0h2p21cheIu7klFPV9fZCED5nu9ITR1tOBFKJ1woxbhXhy7TxgZDZD').json()
  idfb=check['id']
  avarta=avarta['data']['url']
  created_time=check['created_time']
  hometown=check.get('hometown',{}).get('name')
  username=check.get('username')
  name=check['name']
  locale=check.get('locale')
  location=check.get('location',{}).get('name')
  website=check.get('website')
  birthday=check.get('birthday')
  gender=check.get('gender')
  relationship_status=check.get('relationship_status')
  first_name=check['first_name']
  subscribers=check['subscribers']['summary']["total_count"]
  link=check['link']
  data = {'idfb':idfb, 'link':link, 'avarta':avarta, 'created_time':created_time, 'hometown':hometown, 'username':username, 'name':name,
  'locale':locale, 'location':location, 'website':website, 'birthday':birthday, 'gender':gender, 'relationship_status':relationship_status, 'first_name':first_name, 'subscribers':subscribers}
  check=json.loads(json.dumps(data,indent=13))
  return check



