import requests
import json
def checkid(uid):
  check=requests.get(f'https://graph.facebook.com/{uid}?fields=id,is_verified,cover,created_time,work,hometown,username,link,name,locale,location,about,website,birthday,gender,relationship_status,significant_other,quotes,first_name,subscribers.limit(0)&access_token=EAAD6V7os0gcBOZBIXZAt6G7rUkcMx4ZC1ZByZCgrSDaLjNB2sZBzTLfSrjA4nm6ZACzqugGZBZCbOXwJfsZC99diUbtPRZAZA5hxqmwv9eJxRMqgGEaUZBMmvuWzmbZBZCLt19bkPVV9GYsVss0HxbIJpRJcLpe6utdG6QkFGoN7NLQZACiIIMgbOKG6rmLdUKmZCBAZDZD').json()
  #avarta=requests.get(f'https://graph.facebook.com/{uid}/picture?redirect=0&type=normal&height=350&width=350&access_token=EAAD6V7os0gcBOZBIXZAt6G7rUkcMx4ZC1ZByZCgrSDaLjNB2sZBzTLfSrjA4nm6ZACzqugGZBZCbOXwJfsZC99diUbtPRZAZA5hxqmwv9eJxRMqgGEaUZBMmvuWzmbZBZCLt19bkPVV9GYsVss0HxbIJpRJcLpe6utdG6QkFGoN7NLQZACiIIMgbOKG6rmLdUKmZCBAZDZD').json()
  idfb=check['id']
  #avarta=avarta['data']['url']
  created_time=check['created_time']
  hometown=check.get('hometown',{}).get('name')
  username=check.get('username')
  name=check['name']
  locale=check.get('locale')
  location=check.get('location',{}).get('name')
  website=check.get('website')
  birthday=check.get('birthday')
  gender=check.get('gender')
  relationship_status=check.get('relationship_status')
  first_name=check['first_name']
  subscribers=check['subscribers']['summary']["total_count"]
  link=check['link']
  data = {'idfb':idfb, 'link':link, 'created_time':created_time, 'hometown':hometown, 'username':username, 'name':name,
  'locale':locale, 'location':location, 'website':website, 'birthday':birthday, 'gender':gender, 'relationship_status':relationship_status, 'first_name':first_name, 'subscribers':subscribers}
  check=json.loads(json.dumps(data,indent=13))
  return check



