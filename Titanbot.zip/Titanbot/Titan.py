from fbchat import Client, log, Message
from fbchat.models import *
import random
import requests
import json
import sys
import threading
from viewstr import fb
from apiddos import attack
try:
    with open('config.json') as f:
        configuration = json.load(f)
except (FileNotFoundError, json.decoder.JSONDecodeError):
    print("\033[1m\033[91mSORRY, AN ERROR ENCOUNTERED WHILE FINDING OR READING 'CONFIGURATION.JSON'.\033[0m")
    sys.exit()

class AutoBot(Client):
    def sendmessage(self, author_id, thread_id, thread_type, reply):
        if author_id != self.uid:
            self.send(Message(text=reply), thread_id=thread_id, thread_type=thread_type)

    def sendimg(self, author_id, thread_id, thread_type, image_url):
        if author_id != self.uid:
            reply = random.choice(['Gái Xinh Nek😋', 'Húp Được Không Mà Nhìn😼', 'Nứng Chưa?😎'])
            self.sendRemoteImage(image_url, message=Message(text=reply), thread_id=thread_id, thread_type=thread_type)

    def onMessage(self, mid=None, author_id=None, message_object=None, thread_id=None, thread_type=ThreadType.USER, **kwargs):
        global viewstr_progress
        msg = message_object.text
        rainbow_light_text_print("[ [ MESSAGE ] ] " + msg + " From " + author_id)
        if author_id != self.uid:
            if msg.startswith(f"{configuration['CONFIG']['BOT_INFO']['PREFIX']}attack"):
              try:
                target= msg.split(' ')[1]
                time= int(msg.split(' ')[2])
                if time > 60:
                  reply='Max 60 Bạn Ơi😎'
                  self.sendmessage(author_id, thread_id, thread_type, reply)
                else:
                  def f():
                    atk= attack(target,time)
                    if atk == True:
                      reply=f'Send Attack Success☠️\n\nTarget:{target}\nTime:{time}'
                      self.sendmessage(author_id, thread_id, thread_type, reply)
                    else:
                      reply='Send Attack Fail🤧.Vui Lòng Đợi Vài Phút!'
                      self.sendmessage(author_id, thread_id, thread_type, reply)
                  success_atk=threading.Thread(target=f)
                  success_atk.start()
                  
              except Exception as e:
                print(f"Error in onMessage: {e}")
                reply='Cách Sử Dụng:/attack target time\n\nTime Max:60 Min:15'
                self.sendmessage(author_id, thread_id, thread_type, reply)
            if 'girl' in msg:
                image_url = requests.get('https://tthanhvippro.000webhostapp.com/getanh.php').text
                self.sendimg(author_id, thread_id, thread_type, image_url)
            if msg.startswith(f"{configuration['CONFIG']['BOT_INFO']['PREFIX']}viewstr"):
              if viewstr_progress:
                reply='⌛Hiện Tại Đang Có 1 Đơn Chưa Hoàn Thành.Vui Lòng Chờ Trong Vài Phút!'
                self.sendmessage(author_id, thread_id, thread_type, reply)
              else:
                viewstr_progress=True
                try:
                  link = msg.split(' ')[1]
                  a = int(msg.split(' ')[2])
                  if not 'https://www.facebook.com/stories/' in link:
                    reply='Sai Link Story FACEBOOK Rồi Bạn Ơi!'
                    self.sendmessage(author_id, thread_id, thread_type, reply)
                    viewstr_progress=False
                  if a > 1000:
                    reply=f' Max 1000 Bạn Ơi🤧'
                    self.sendmessage(author_id, thread_id, thread_type, reply)
                    viewstr_progress=False
                  else:
                    reply = f' Đơn Tiếp Theo\n\n{a} View  Story Cho Link:{link} '
                    self.sendmessage(author_id, thread_id, thread_type, reply)
                    def r():
                      try:
                        idstr = link.split('/')[5].split('/?')[0]
                        fb(idstr, link,a)
                      except Exception as e:
                        return str(e)
                      finally:
                        global viewstr_progress
                        viewstr_progress=False
                        reply = f"🗒ORDER SUCCESSFUL\n\nĐã Buff {a} View Story Cho Link:{link}"
                        self.sendmessage(author_id, thread_id, thread_type, reply)
                    success_viewstr=threading.Thread(target=r)
                    success_viewstr.start()
                except Exception as e:
                  print(f"Error in onMessage: {e}")
                  self.sendmessage(author_id, thread_id, thread_type, ' Cách Sử Dụng: /viewstr Linkstr Số Lượng\n\nMax:1000 View')
                  viewstr_progress= False

viewstr_progress=False

# Thêm thông tin về cookies và khởi tạo bot


def rainbow_light_text_print(text, end='\n'):
    colors = ["\033[91m", "\033[93m", "\033[92m", "\033[96m", "\033[94m", "\033[95m"]
    num_steps = len(colors)
    for i, char in enumerate(text):
        color_index = i % num_steps
        print(f"{colors[color_index]}{char}", end="")
    print("\033[0m", end=end)

try:
  session_cookies = {
    'sb': 'DQ97ZXbUjyNXSnJZhVvdQhRw',
    'datr': 'Ag97ZQkf2HI76IguHusu-GkE',
    'c_user': '100093063091825',
    'fr': '16HxDixEXO3E2ptmr.AWXPIgKbaBfA7km3uhAVldgRt0U.Blk6a2.7I.AAA.0.0.Blk977.AWXeLeIclc4',
    'xs': '6%3AFi1BhHFGsxKm8w%3A2%3A1704189689%3A-1%3A6274',
}
  bot = AutoBot('', '', session_cookies=session_cookies)
  rainbow_light_text_print("[ [ CONNECTING ] ] {}".format(str(bot.isLoggedIn()).upper()))
except:
  sys.exit("\033[91m[ [ ERROR ] ] FAILED TO CONNECT TO SERVER, TRY TO RERUN TO PROGRAM. \033[0m")
try:
  bot.listen()
except:
  bot.listen()
#datr=; sb=; wl_cbv=v2%3Bclient_version%3A2378%3Btimestamp%3A1703168219; vpd=v1%3B947x891x2.061462879180908; locale=en_GB; wd=891x1745; dpr=2.061462879180908; c_user=100093063091825; xs=; fr=; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTIwLjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F120.0.0.0%20Mobile%20Safari%2F537.36; 