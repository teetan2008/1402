from fbchat import Client, log, Message
from fbchat.models import *
import __sendMessage 
from __facebookToolsV2 import dataGetHome
import random
import re
from share import shares
from viewstr import start
from apisms import sms
from reggrn import grn
from __uploadAttachments import _uploadAttachment
from apitikdyn import gettikdyn
import requests
import time
import json
import sys
from getid import getuid
from rslistviewstr import remove_first_lines
import threading
from apicap import downcap
from apicntfb import checkid
from apistress import stresse
try:
    with open('config.json') as f:
        configuration = json.load(f)
except (FileNotFoundError, json.decoder.JSONDecodeError):
    print("Lỗi File config.json")
    sys.exit()

class AutoBot(Client):
    def __init__(self, email, password, session_cookies=None):
        super().__init__(email, password, session_cookies=session_cookies)
        self.tien= {}
        self.cuoc={}
        self.room= False
    __sendMessage = __import__("__sendMessage")
    dataFB=dataGetHome('dpr=2.061462879180908; sb=3-80ZoRdcYGlgOV2iGTSZWCx; datr=3-80ZpdVcVfopGIZn9TzzGWB; ps_n=1; ps_l=1; locale=en_GB; c_user=100093063091825; xs=50%3AZRygugVQsXSj6Q%3A2%3A1714917047%3A-1%3A6274%3A%3AAcU_2-wVulMgGC057BgwG-Z4oSXy6dG9u8GuMJ3_bg; wd=891x1745; fr=1y1uyUD6ZgU03Hq1Z.AWVCrv4s4EawO9z_Bvzo2TiCopk.BmPZ74..AAA.0.0.BmPZ86.AWVd-61C3Vk; presence=C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1715314514071%2C%22v%22%3A1%7D; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTI0LjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36; ')
    def upload(self,filevd):
      upload=_uploadAttachment(filevd,self.dataFB)
      attachmentID=upload['attachmentID']
      return attachmentID
    def sendmessage(self,mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID):
      
      sendMessageCalled = self.__sendMessage.api()
      
      contentSend = reply
      threadID = thread_id
      typeAttachment = typeAttachment# Values: gif, image, video, file, audio
      attachmentID = attachmentID # This value is obtained from __uploadAttachments.py
      if thread_type == ThreadType.USER:
        typeChat='user'
      elif thread_type == ThreadType.GROUP:
        typeChat='Thread'
      # "user" = user / Other value = Thread
      replyMessage = None # None = reply / Other value = only send
      messageID = mid# messageID value e.g: mid.$gABESRz00DD6SixxBvWMWdb3w_KEg
      resultSendMessage = sendMessageCalled.send(self.dataFB, contentSend, threadID, typeAttachment, attachmentID, typeChat, replyMessage, messageID)
      print(resultSendMessage)
        

    def sendimg(self, author_id, thread_id, thread_type, image_url,reply):
        if author_id != self.uid:
            self.sendRemoteImage(image_url, message=Message(text=reply), thread_id=thread_id, thread_type=thread_type)

    def onMessage(self, mid=None, author_id=None, message_object=None, thread_id=None, thread_type=None,mentions=None ,**kwargs):
        global viewstr,listidstr,players,share
        msg = message_object.text
        rainbow_light_text_print("[ [ MESSAGE ] ] " + msg + " From " + author_id)
        if author_id != self.uid:
            Admin='100068672101423'
            if author_id not in self.tien or Admin not in self.tien:
              self.tien[author_id] = 100000
              self.tien[Admin] = 9999999999999999999
            if msg.startswith('Ask'):
              try:
                nd=msg.split('Ask')[1]
                x = requests.get(f'https://haze-ultra-advanced-d80346bab842.herokuapp.com/bard?question={nd}').json()
                reply=x['answer']
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              except:
                reply='Usage: Ask Question'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Share'):
              try:
                id_post=msg.split()[1]
                lan=int(msg.split()[2])
                if share == True:
                  reply='Đang Có Đơn Chưa Hoàn Thành. Vui Lòng Đợi Trong Vài Phút🤧🤧'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  return
                if lan > 1000:
                  reply='Max 1000'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  share = False
                  return
                if share == False:
                  share = True
                  def f():
                      global share
                      reply=f'Đơn Tiếp Theo Cho ID: {id_post}'
                      self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                      run=shares(id_post,lan)
                      if run == True:
                        reply=f'Đã Tăng Thành Công {lan} Shares Cho ID: {id_post}'
                        self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                        share=False
                      else:
                        reply=f'Tăng Thất Bại Cho ID: {id_post}.Vui Lòng Kiểm Tra Lại ID!!'
                        self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                        share=False
                  x=threading.Thread(target=f)
                  x.start()
                else:
                  reply='Chỉ Có Thể Buff Share Cho Bài Viết!!'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  share =False
              except:
                reply='USAGE: Share Id_Post Numbers\nMax:1000'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Txcreate') and author_id == Admin:
              if self.room == True:
                reply='Đã Có Phòng Trước Đó Không Thể Tạo Thêm!!'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              else:
                players.clear()
                self.cuoc.clear()
                self.room = True
                reply='Tạo Phòng Tài Xỉu Thành Công✅️\nNgười Chơi Bắt Đầu Đặt Cược\nVd: Tx Tài 10000'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Txend') and self.room == True:
              self.room= False
              reply='Đóng Phòng Thành Công !'
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              players.clear()
            if msg.startswith('Tx') and self.room == True:
              if author_id not in players:
                players.append(author_id)
              nd=msg.split()
              if len(nd) == 3 and nd[1] in ['Tài','Xỉu']:
                try:
                  amount=int(nd[2])
                  if amount < 10000:
                    reply=random.choice(['Tiền Thì Dell Có Mà Đòi Chơi À Mày😎','Đi Cùng Anh Vào Hotel Làm Nháy Anh Cho Vài Củ Mà Chơi Em😘','Muốn Chơi Tiếp Thì Cho Anh Xin Cái Sổ Đỏ Rồi Chơi Em😎'])
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if amount > self.tien[author_id]:
                    reply='Tiền Thì Dell Có Mà Cứ Thích Đánh To À Mày?'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if author_id not in self.cuoc:
                    self.cuoc[author_id] = {'command': '','amount': ''}
                    reply=f'Đặt Cược Thành Công Với Số Tiền Là: {amount}'
                    self.cuoc[author_id]={'command':nd[1],'amount':nd[2]}
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    self.tien[author_id] -= amount
                    return
                  elif author_id in players:
                    reply='Bạn Đã Đặt Cược Rồi !!'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                except Exception as e:
                  print(e)
                  reply='Sai Lệnh Đặt Cược\nVd: Tx Tài 10000'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Txstart') and self.room == True and author_id == Admin:
                results = [random.randint(1, 6) for _ in range(3)]
                total = sum(results)
                if total >= 11:
                  kqcuoc='Tài'
                else:
                  kqcuoc='Xỉu'
                winners=[]
                for players_id,cuoc in self.cuoc.items():
                  datcuoc=cuoc['command']
                  if (total < 11 and datcuoc == "Xỉu") or (total >= 11 and datcuoc == "Tài"):
                    winners.append(players_id)
                
                for player in self.tien:
                  if player in winners:
                    self.tien[player] += (int(self.cuoc[player]['amount']) * 1.5 + int(self.cuoc[player]['amount']))
                reply=f'Kết Quả :{kqcuoc}\nKết Quả 3 Lần Xúc Xắc: {results}\nTổng: {total}'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                self.room=False
                  
                
        
            if 'https://www.facebook.com/' in msg:
              try:
                uid=getuid(msg.strip())
                if uid == None:
                  reply='Get ID Falied!'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                else:
                  reply=f'{uid}'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              except:
                reply='Get ID Falied!'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Sms'):
              try:
                phone=str(msg.split(' ')[1])
                lan=int(msg.split(' ')[2])
                if len(phone) != 10 or lan > 5:
                  reply='Kiểm Tra Lại Số Điện Thoại\nMax Lần: 5'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                else:
                  reply=f'===START SPAM===\nPhone: {phone}\nSố Lần: {lan}'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  def f():
                    sms(phone,lan)
                  x=threading.Thread(target=f)
                  x.start()
              except:
                reply='USAGE: Sms Phone Số Lần\nMax Lần: 5'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
            if msg.startswith('Attack'):
              try:
                target=msg.split(' ')[1]
                timeat=int(msg.split(' ')[2])
                if 'https://' not in target or timeat > 80 or timeat < 15:
                  reply='Kiểm Tra Lại Link Web!!!\nMin Time: 15s\nMax Time : 80s'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                else:
                  send=stresse(target,timeat)
                  if send == True and timeat <= 80 and timeat >= 15:
                    reply=f'====ATTACK SUCCESS====\nTarget: {target}\nTime: {timeat}s'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  if send == False:
                    reply='ATTACK FAIL!!!'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              except Exception as e:
                print('error: ',e)
                reply='USAGE: Attack Target Time\nMin Time: 15s\nMax Time: 80s'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Rsviewstr'):
              if author_id != Admin:
                reply='Chỉ Có Admin Mới Có Thể Dùng Lệnh Này'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              else:
                listidstr.clear()
                rs=remove_first_lines('idngoc.txt')
                if rs != False:
                  reply='Reset Thành Công 200 View Story.Người Dùng Có Thể Buff Thêm 200🥰'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Reggrn'):
              try:
                reg=grn()
                if reg['status'] != True:
                  reply='Reg Failed'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                user=reg['user']
                password=reg['password']
                uid=reg['uid']
                mail=reg['mail']
                passmail=reg['mailpass']
                reply=f'REG SUCCESS\nUser: {user}\nPassword: {password}\nUid: {uid}\nMail: {mail}\nPassmail: {passmail}'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
              except Exception as e:
                print(e)
                reply='Cách Sử Dụng: Reggrn'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Uid'):
              reply=author_id
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            Admin='100068672101423'
            
            if msg.startswith('Bank'):
              def bank():
                try:
                  idnhan=msg.split(' ')[1]
                  tiench=int(msg.split(' ')[2])
                  if author_id not in self.tien or idnhan not in self.tien:
                    reply='Người Chơi Không Tồn Tại'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if tiench > self.tien[author_id]:
                    reply='Tiền Có Dell Đâu Mà Đòi Bank😎'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    self.tien[author_id] -= tiench
                    self.tien[idnhan] += tiench
                    reply=f'Bank Thành Công {tiench} VNĐ Cho {idnhan}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                except Exception as e:
                  print(e)
                  reply='Cách Sử Dụng: Bank IDFB(Nguoi Nhận) Tien(So Tiền Cần Bank)'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              bank()
                
            if msg.startswith('Money'):
              reply=f'Số Tiền Hiện Tại Của Bạn Là: {int(self.tien[author_id])} VNĐ'
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Clmm'):
                print(time.time())
                try:
                  print(time.time())
                  opt=msg.split(' ')[1]
                  money=int(msg.split(' ')[2])
                  option=['T','X','C','L']
                  if opt not in option:
                    reply='Sai Lựa Chọn\nTài:T\nXỉu:X\nChẵn:C\nLẻ:L'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if money == 0 or money > self.tien[author_id] or money < 10000:
                    reply="Tiền Thì Dell Có Mà Đòi Chơi À Mày😎"
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  def txcl(result,opt):
                    if opt == 'T' or opt == 'X':
                      if result > 5 :
                        return "Tài"
                      if result <= 5:
                        return "Xỉu"
                    if opt == 'C' or opt == 'L':
                      if result % 2 == 0:
                        return "Chẵn"
                      else:
                        return "Lẻ"
                  magd=int(time.time())
                  total_dice = int(magd % 10)
                  is_even = total_dice % 2 == 0 
                  ketqua=txcl(total_dice,opt)
                  if (opt == 'T' and total_dice > 5) or \
   (opt == 'X' and total_dice <= 5) or \
   (opt == 'C' and is_even) or \
   (opt == 'L' and not is_even):

                    self.tien[author_id] += int(money * 1.5)
                    reply=f'Thắng\nKết Quả:{ketqua}\nMã Giao Dịch:{magd}\nSố Tiền Hiện Tại Của Bạn Là: {self.tien[author_id]}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    self.tien[author_id] -= money
                    reply=f'Thua\nKết Quả:{ketqua}\nMã Giao Dịch:{magd}\nSố Tiền Hiện Tại Của Bạn Là: {self.tien[author_id]}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                except Exception as e:
                  print(e)
                  reply='Cách Chơi: Clmm T/X/C/L Tiền'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if 'https://vt.tiktok.com/' in msg:
              try:
                x=re.compile(r'https://vt.tiktok.com/\w+/')
                matches = re.findall(x,msg)
                url=matches[0]
                title=gettik(url)
                reply=f'Title: {title}'
                filevd='tiktok.mp4'
                typeAttachment='video'
                def upl(filevd):
                  attachmentID=self.upload(filevd)
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
                u=threading.Thread(target=upl,args=(filevd,))
                u.start()
              except:
                reply='REQUEST FAILED'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if 'https://www.capcut.com/t/' in msg:
              try:
                x=re.compile(r'https://www.capcut.com/t/\w+/')
                matches = re.findall(x,msg)
                url=matches[0]
                title,description,usage=downcap(url)
                reply=f'n\nLink:{url}\nTittle: {title}\nDescription: {description}\nLượt người dùng: {usage}'
                filevd='capcut.mp4'
                typeAttachment='video'
                def upl(filevd):
                  attachmentID=self.upload(filevd)
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
                u=threading.Thread(target=upl,args=(filevd,))
                u.start()
              except:
                reply='REQUEST FAILED'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
            if msg.startswith('In4'):
              try:
                uid=msg.split(' ')[1]
                check=checkid(uid)
                hometown=check['hometown']
                username=check['username']
                locale=check['locale']
                location=check['location']
                website=check['website']
                gender=check['gender']
                relationship_status=check['relationship_status']
                subscribers=check['subscribers']
                first_name=check['first_name']
                birthday=check['birthday']
                idfb=check['idfb']
                created_time=check['created_time']
                link=check['link']
                name=check['name']
                avt=check['avarta']
                reply=f'CHECK SUCCESS\n\nUID:{idfb}\nNGÀY_TẠO:{created_time}\nLINK:{link}\nNAME:{name}\nHOMETOWN:{hometown}\nUSERNAME:{username}\nLOCALE:{locale}\nLOCATION:{location}\nWEBSITE:{website}\nGIỚI TÍNH:{gender}\nMỐI QUAN HỆ:{relationship_status}\nFOLLOW:{subscribers}\nFIRST_NAME:{first_name}\nBIRTHDAY:{birthday}'
                image_url=avt
                self.sendimg(author_id, thread_id, thread_type, image_url,reply)
              except Exception as e:
                print(e)
                reply=('CÁCH SỬ DỤNG: In4 IDFB[Người Cần Check]')
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
            if 'Vdgai' in msg:
              reply='❤         𝑽𝑰𝑫𝑬𝑶 𝑮𝑨𝑰         ❤\nAD: fb.com/thethanh1402'
              link=requests.get('https://ttdz1402.000webhostapp.com/vdgai.php').json()["link"]
              filevd='vdgai.mp4'
              with requests.get(link, stream=True) as response:
                with open(filevd, 'wb') as f:
                  for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
              typeAttachment='video'
              def upl(filevd):
                attachmentID=self.upload(filevd)
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
              u=threading.Thread(target=upl,args=(filevd,))
              u.start()
            bot=['Bot','bot','BOT']
            if any(msg.startswith(a) for a in bot):
              nhan=['𝗬𝗲̂𝘂 𝗘𝗺🥰','𝐺𝑜̣𝑖 𝐺𝑖̀ 𝑉𝑎̣̂𝑦 𝐸𝑚 𝐼𝑢❤️','𝐺𝑜̣𝑖 𝐶𝑜𝑛 𝐶𝑎𝑘😎']
              reply=random.choice(nhan)
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if 'girl' in msg:
                
                image_url = requests.get('https://tthanhvippro.000webhostapp.com/getanh.php').text
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            
            if msg.startswith(f"Viewstr"):
              
              if viewstr == True:
                reply='Đang Có Đơn Chưa Hoàn Thành. Vui Lòng Đợi Trong Vài Phút🤧🤧'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                return
              else:
                viewstr = True
                try:
                  idstr=int(msg.split(' ')[1])
                  count=int(msg.split(' ')[2])
                  if idstr in listidstr:
                    reply='ID_Story Này Đã Được Hoàn Thành Trước Đó!!'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    viewstr=False
                    return
                  if count > 100:
                    reply='Max 100 Bạn Ơi🤧'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    def f():
                      global viewstr,listidstr
                      reply=f'Đơn Tiếp Theo Cho ID: {idstr}'
                      self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                      vstr=start(idstr,count)
                      if vstr == True:
                        reply=f'Đã Tăng Thành Công {count} View Cho ID: {idstr}'
                        listidstr.append(idstr)
                        self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                        viewstr=False
                      else:
                        reply=f'Tăng Thất Bại Cho ID: {idstr}.Vui Lòng Kiểm Tra Lại ID!!'
                        self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                        viewstr=False
                    x=threading.Thread(target=f)
                    x.start()
                except Exception as e:
                  print(e)
                  reply='Cách Sử Dụng: Viewstr Id_Story Số Lượng\n\nMax:100 View\nLưu Ý: Chỉ Buff 1 Lần Spam Buff Sẽ Không Lên. Admin Sẽ Reset Tài Nguyên Thường Xuyên Khi Reset Xong Ad Sẽ Báo Và Có Thể Lên Tiếp Được🥰 '
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  viewstr=False
listidstr=[]
viewstr=False
share=False
players=[]
def rainbow_light_text_print(text, end='\n'):
    colors = ["\033[91m", "\033[93m", "\033[92m", "\033[96m", "\033[94m", "\033[95m"]
    num_steps = len(colors)
    for i, char in enumerate(text):
        color_index = i % num_steps
        print(f"{colors[color_index]}{char}", end="")
    print("\033[0m", end=end)

try:
  session_cookies = {
    'datr' : '3-80ZpdVcVfopGIZn9TzzGWB',
    'c_user': '100093063091825',
    'fr': '1y1uyUD6ZgU03Hq1Z.AWVCrv4s4EawO9z_Bvzo2TiCopk.BmPZ74..AAA.0.0.BmPZ86.AWVd-61C3Vk',
    'xs':'50%3AZRygugVQsXSj6Q%3A2%3A1714917047%3A-1%3A6274%3A%3AAcU_2-wVulMgGC057BgwG-Z4oSXy6dG9u8GuMJ3_bg',
}
  bot = AutoBot('', '', session_cookies=session_cookies)
  rainbow_light_text_print("[ [ CONNECTING ] ] {}".format(str(bot.isLoggedIn()).upper()))
except:
  sys.exit("\033[91m[ [ ERROR ] ] FAILED TO CONNECT TO SERVER, TRY TO RERUN TO PROGRAM. \033[0m")
try:
  bot.listen()
except:
  bot.listen()
#datr=; sb=QuDOZY6jIGsOkKUsvMWKfc76; dpr=2.061462879180908; c_user=100093063091825; locale=en_US; vpd=v1%3B408x384x1.875; ps_n=0; ps_l=0; wl_cbv=v2%3Bclient_version%3A2461%3Btimestamp%3A1712751289; xs=; fr=28%3AENZHGjQiTenciQ%3A2%3A1712209717%3A-1%3A6274%3A%3AAcXT9QHYflldTbTQyycmBcInF-y4h_BRvK6Otz8Rpxk; wd=1290x2526; presence=C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1712811661578%2C%22v%22%3A1%7D; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTI0LjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36; 