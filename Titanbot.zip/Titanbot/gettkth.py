import requests

token = input("Nhập token:")
file = 'id.txt'
fileluu = 'token.txt'

with open(file, "r") as fileid:
    for line in fileid:
        idp = line.strip()
        try:
            response = requests.get(f"https://graph.facebook.com/{idp}/?fields=name,access_token&access_token={token}")
            data = response.json()
            if 'access_token' in data:
                access_token = data['access_token']
                with open(fileluu, 'a') as token_file:
                    token_file.write(access_token + '\n')
            else:
                print(f"Không tìm thấy access token cho ID {idp}")
        except requests.exceptions.RequestException as e:
            print(f"Lỗi khi thực hiện yêu cầu cho ID {idp}: {e}")
        except KeyError:
            print(f"Không thể truy cập vào access token cho ID {idp}")
