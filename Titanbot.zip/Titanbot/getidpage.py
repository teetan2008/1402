import requests, os, sys, json
from threading import Thread
import threading
do = "\033[1;91m"
trang = "\033[1;37m"
xanhbien = "\033[1;36m"
vang = "\033[0;33m"
hong = "\033[1;35m"
xanhduong = "\033[1;34m"
xanhla = "\033[1;32m"
xanh="\033[1;32m"
cam="\033[1;33m"
blue="\033[1;34m"
lam="\033[1;34m"
tim="\033[1;34m"
syan="\033[1;36m"
xnhac= "\033[1;96m"
den="\033[1;90m"
luc="\033[1;92m"
xduong="\033[1;94m"
edit = vang+"]"+trang+"["+luc+"•√•"+trang+"]"+vang+"["+trang+" => "+luc
edit1 = trang+"["+luc+"•√•"+trang+"]"+trang+" => "+luc
banner = f"""
{trang}= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
"""
dem=0
def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
def gettoken(id, name, file):
	
	url = "https://mbasic.facebook.com/"+id
	url = requests.get(url).url
	if "1000" in url:
		print(luc+"[PAGE PRO5] => "+id)
		print(trang+"= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
	else:
		print(vang+"[FAN PAGE] => "+id)
		print(trang+"= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
	open(file,"a+").write(id+"\n")

def main():
	clear()
	print(banner)
	while True:
		cookie = "sb=G4aWY_EgUYvf3Cy6yzz6f0FN; datr=TiGyY2byYuy5UuOeSzmDkRKr; dpr=2.75; c_user=100076488491984; xs=13%3AGd7HrAT3L7P-vA%3A2%3A1683030564%3A-1%3A6283; m_page_voice=100076488491984; fbl_ci=2529992720476222; locale=vi_VN; fbl_cs=AhDVwYcXAh1NB%2FvOZ109FhVtGEs4TVA0cEpMMUM1Tk5kdVlDbVY9RXNhRA; fr=0LIn0cZ4qXEJCGSm3.AWW2b791FfDLI2uPHDuIWZZngtg.BkV5tI.ae.AAA.0.0.BkV5tI.AWViKLzQRGs; wd=1024x1201; fbl_st=100430778%3BT%3A28057813; wl_cbv=v2%3Bclient_version%3A2243%3Btimestamp%3A1683468816; vpd=v1%3B461x393x2.75; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEyOyBNMjEwMUs3QkcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDUuMC4wLjAgTW9iaWxlIFNhZmFyaS81MzcuMzY%3D; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2012%3B%20M2101K7BG)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F105.0.0.0%20Mobile%20Safari%2F537.36; "
		token = input(edit+"NHẬP TOKEN FULL QUYỀN: "+trang)
		threa = int(input(print("!",f"INPUT THREAD: ")))
		get = requests.get("https://graph.facebook.com/me/?fields=id,name&access_token="+token).json()
		try:
			idfb = get["id"]
			namefb = get["name"]
			get = requests.get("https://graph.facebook.com/me/accounts?fields=id,name,access_token&access_token="+token, headers={"cookie":cookie}).json()["data"]
			print(get)
			if str(len(get)) == "0":
				print(do+"TOKEN KHÔNG CÓ PAGE")
				continue
			else:break
		except:
			print(do+"TOKEN DIE")
			continue
	file = input(edit+"NHẬP FILE MUỐN LƯU TOKEN: "+trang)
	for i in get:
	    id = i["id"]
	    name = i["name"]
	    t = threading.Thread(target=gettoken, args=(id, name, file))
	    t.start()
	    while threading.active_count() > threa:
	      t.join()

main()