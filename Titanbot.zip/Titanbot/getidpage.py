import requests
import os
import threading

do = "\033[1;91m"
trang = "\033[1;37m"
luc = "\033[1;92m"

def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def gettoken(id, token, name, file):
    url = "https://mbasic.facebook.com/" + id
    url = requests.get(url).url
    if "1000" in url:
        print(luc + "[PAGE PRO5] => " + id)
        print(trang + "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    else:
        print(do + "[FAN PAGE] => " + id)
        print(trang + "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    open(file, "a+").write(token + "\n")
    open('id.txt', 'a+').write(id + '\n')

def main():
    clear()
    while True:
        cookie = "sb=G4aWY_EgUYvf3Cy6yzz6f0FN; datr=TiGyY2byYuy5UuOeSzmDkRKr; dpr=2.75; c_user=100076488491984; xs=13%3AGd7HrAT3L7P-vA%3A2%3A1683030564%3A-1%3A6283; m_page_voice=100076488491984; fbl_ci=2529992720476222; locale=vi_VN; fbl_cs=AhDVwYcXAh1NB%2FvOZ109FhVtGEs4TVA0cEpMMUM1Tk5kdVlDbVY9RXNhRA; fr=0LIn0cZ4qXEJCGSm3.AWW2b791FfDLI2uPHDuIWZZngtg.BkV5tI.ae.AAA.0.0.BkV5tI.AWViKLzQRGs; wd=1024x1201; fbl_st=100430778%3BT%3A28057813; wl_cbv=v2%3Bclient_version%3A2243%3Btimestamp%3A1683468816; vpd=v1%3B461x393x2.75; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEyOyBNMjEwMUs3QkcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDUuMC4wLjAgTW9iaWxlIFNhZmFyaS81MzcuMzY%3D; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2012%3B%20M2101K7BG)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F105.0.0.0%20Mobile%20Safari%2F537.36; "
        token = input("NHẬP TOKEN FULL QUYỀN: ")
        threa = int(input("INPUT THREAD: "))
        get = requests.get("https://graph.facebook.com/me/?fields=id,name&access_token=" + token).json()
        try:
            idfb = get["id"]
            namefb = get["name"]
            get = requests.get("https://graph.facebook.com/me/accounts?fields=id,name,access_token&access_token=" + token, headers={"cookie": cookie}).json()["data"]
            print(get)
            if str(len(get)) == "0":
                print(do + "TOKEN KHÔNG CÓ PAGE")
                continue
            else:
                break
        except:
            print(do + "TOKEN DIE")
            continue
    file = input("NHẬP FILE MUỐN LƯU TOKEN: ")
    for i in get:
        id = i["id"]
        token = i['access_token']
        name = i["name"]
        t = threading.Thread(target=gettoken, args=(id, token, name, file))
        t.start()
        while threading.active_count() > threa:
            t.join()

main()
