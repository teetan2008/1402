import random
import string
import requests
import re
import time
import json
def generate_random_string(length):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def register_mail():
    user = generate_random_string(10)
    mail = ''.join([random.choice(string.ascii_lowercase) + str(random.randint(1, 100)) for _ in range(4)])
    domain = requests.get("https://api.mail.tm/domains?page=1", headers={"content-type": "application/json"}).json()["hydra:member"][0]["domain"]
    mail += "@" + domain
    password = "@TThanh2008"
    data = '{"address":"' + mail + '","password":"' + password + '"}'
    acc = requests.post("https://api.mail.tm/accounts", data, headers={"content-type": "application/json"}).json()
    token = requests.post("https://api.mail.tm/token", data, headers={"content-type": "application/json"}).json()["token"]
    return token, mail, user

def send_verification_code(token, mail):
    user = generate_random_string(10)
    cookies = {
        '_ga': 'GA1.1.21185530.1693826229',
        '_ga_1M7M9L6VPX': 'GS1.1.1693885492.2.0.1693885492.0.0.0',
        'datadome': 'OUobR~7P2FnboZRLS4tn_ieEGKjjNGOooYfcAVww296HzCZfdfOI~uqYQWcdRcDHTiuobqMpDES3URbgHkwhPPsYkiPQ7eHxJHBA3vZKhBxgT_uRQZxObw0y~92P~1zV',
    }
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'Origin': 'https://sso.garena.com',
        'Referer': 'https://sso.garena.com/universal/register?redirect_uri=https://sso.garena.com/universal/login?app_id=10100%26redirect_uri=https%253A%252F%252Faccount.garena.com%252F%26locale=vi-VN',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'x-datadome-clientid': 'OUobR~7P2FnboZRLS4tn_ieEGKjjNGOooYfcAVww296HzCZfdfOI~uqYQWcdRcDHTiuobqMpDES3URbgHkwhPPsYkiPQ7eHxJHBA3vZKhBxgT_uRQZxObw0y~92P~1zV',
    }
    data = {
        'username': user,
        'email': mail,
        'locale': 'vi-VN',
        'format': 'json',
        'id': '1703494047664',
    }
    response = requests.post('https://sso.garena.com/api/send_register_code_email', cookies=cookies, headers=headers, data=data).json()
    return response, user

def check_verification_code(token):
    headers = {
        'authorization': f'Bearer {token}',
    }
    response = requests.get('https://api.mail.tm/messages', headers=headers).json()['hydra:member']
    for message in response:
        message_id = message['@id']
        message_text = requests.get(f'https://api.mail.tm{message_id}', headers=headers).json()["text"]
        match = re.search(r'\b(\d{8})\b', message_text)
        if match:
            return match.group(1)
    return None

def register_grn(user, mail, code):
    cookies = {
        '_ga': 'GA1.1.21185530.1693826229',
        '_ga_1M7M9L6VPX': 'GS1.1.1693885492.2.0.1693885492.0.0.0',
        'datadome': 'VevdyHdFqnpkRcJ1~0lk8ZeZ~EUeipunOJf9~ZK9qvP84QyRZi4~kZN8q1s_Qj3ZZYcLrO82IzRZeWsFhAcN12fHpi5LK2Ht~pcTDNJ4ceMCfey3QYkSfv61OqHLdax3',
    }
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'Origin': 'https://sso.garena.com',
        'Referer': 'https://sso.garena.com/universal/register?redirect_uri=https://sso.garena.com/universal/login?app_id=10100%26redirect_uri=https%253A%252F%252Faccount.garena.com%252F%26locale=vi-VN',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'x-datadome-clientid': 'VevdyHdFqnpkRcJ1~0lk8ZeZ~EUeipunOJf9~ZK9qvP84QyRZi4~kZN8q1s_Qj3ZZYcLrO82IzRZeWsFhAcN12fHpi5LK2Ht~pcTDNJ4ceMCfey3QYkSfv61OqHLdax3',
    }
    data = {
        'username': user,
        'email': mail,
        'email_otp': code,
        'password': '5b923463e8c73962fad427c9f90b1f96cf246acb54043ee8348a53f1ac4260815bbeccc39b5ba2f775c020653a6efdf51db3dad951962aea9ca2b3b2925f6d61a4e9b5a93f2a53c6f8b27a6304815d5df68f42071cfd9695a2c85c2ae596fe77e000f4fb30b1eb4f3187cc2e253ca21dd47c64e42bf18af7eaa5d1fad5b175ce',
        'location': 'SG',
        'mobile_no': '',
        'otp': '',
        'locale': 'vi-VN',
        'redirect_uri': 'https://sso.garena.com/universal/login?app_id=10100&redirect_uri=https%3A%2F%2Faccount.garena.com%2F&locale=vi-VN',
        'format': 'json',
        'id': '1703493546392',
    }
    response = requests.post('https://sso.garena.com/api/register', cookies=cookies, headers=headers, data=data).json()
    try:
        idgrn = response['uid']
        return idgrn
    except KeyError:
        return False

def grn():
    token, mail, user = register_mail()
    send_response, user = send_verification_code(token, mail)
    if 'error_params' not in send_response:
      print("Verification code sent successfully.",'|',mail)
      time.sleep(5)
              # Wait for the verification code to be received
      verification_code = check_verification_code(token)
      if verification_code:
        print(f"Verification Code: {verification_code}")
        uid = register_grn(user, mail, verification_code)
        if uid:
          print('\033[1;32mRegistration Success'+'\033[1;37m')
          data = {'status':True,'user':user,'password':'@TTdz2008','uid':uid,'mail':mail,'mailpass':'@TThanh2008'}
          return json.loads(json.dumps(data))
        else:
          return False
      else:
        data={'status':False}
        return json.loads(json.dumps(data))
    else:
      print(f"Error sending verification code. Mail: {mail}")


