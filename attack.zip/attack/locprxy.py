import os, sys, requests
import concurrent.futures
os.system('cls' if os.name == 'nt' else 'clear')
from threading import Thread
def run():
 f = open(input(' Nhập Files Chứa Proxy: ')).read().split('\n')
 luu = input(' Nhập Files Lưu Proxy Live: ')
 list = []
 for p in f:
  prx = p.strip('\n')
  list.append(prx)
 def runc(proxy):
   try:
    testing = requests.get('http://httpbin.org/ip', proxies={'http': proxy, 'https': proxy}, timeout=3).json()
    print ('\033[1;32m Working | '+proxy)
    open(luu,'a').write(proxy+'\n')
   except:
    print ('\033[1;31m Time Out | '+proxy)
 with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
  executor.map(runc, list)
run()

