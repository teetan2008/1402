a=open('proxies.txt','r').readlines()
for i in a:
  try:
    ip=i.strip().split(':')[0]
    port=i.strip().split(':')[1]
    proxy=ip+':'+port 
    open('proxy.txt','a').write(proxy+'\n')
  except:
    print(i.strip())