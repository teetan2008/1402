import requests
file=input('File: ')
api=['http://huyhoang.ddns.net/vietnam.txt',
     'https://calce.space/proxy.txt',
]
for i in api:
  try:
    x = requests.get(i,timeout=5).text 
    print(f'\033[1;32mSuccess: {i}')
    open(file,'a').write(x)
  except:
    print(f'\033[1;31mFail: {i}')
